
import java.awt.*;

/**
 * Simple shader that just copy the interpolated color to the screen,
 * taking the depth of the fragment into acount.
 * 
 * @author: cdehais
 */
public class TextureShader extends Shader {

    DepthBuffer depth;
    Texture texture;
    boolean combineWithBaseColor;

    public TextureShader(GraphicsWrapper screen) {
        super(screen);
        depth = new DepthBuffer(screen.getWidth(), screen.getHeight());
        texture = null;
    }

    public void setTexture(String path) {
        try {
            texture = new Texture(path);
        } catch (Exception e) {
            System.out.println("Could not load texture " + path);
            e.printStackTrace();
            texture = null;
        }
    }

    public void setCombineWithBaseColor(boolean combineWithBaseColor) {
        this.combineWithBaseColor = combineWithBaseColor;
    }

    public void shade(Fragment fragment) {
        if (depth.testFragment(fragment)) {
            try {



                /* à compléter */
                if (texture != null ) {
                    double u = fragment.getAttribute(7);
                    double v = fragment.getAttribute(8);
                    
                    Color couleurTexture = texture.sample(u , v);

                    if (combineWithBaseColor) {
                        couleurTexture = new Color(
                            (int)(fragment.getColor().getRed() * couleurTexture.getRed() / 255.0),
                            (int)(fragment.getColor().getGreen() * couleurTexture.getGreen() / 255.0),
                            (int)(fragment.getColor().getBlue() * couleurTexture.getBlue() / 255.0)
                        );
                    }
                    screen.setPixel(fragment.getX(), fragment.getY(), couleurTexture);
                } else {
                    
                    System.out.println("pas de texture");
                }



            } catch (ArrayIndexOutOfBoundsException e) {
                screen.setPixel(fragment.getX(), fragment.getY(), fragment.getColor());
            }
            depth.writeFragment(fragment);
        }
    }

    public void reset() {
        depth.clear();
    }
}
