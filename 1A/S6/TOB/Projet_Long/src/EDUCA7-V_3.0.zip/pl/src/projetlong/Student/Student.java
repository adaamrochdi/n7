package projetlong.Student;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Arrays;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import projetlong.GestionneurData;
import projetlong.Main;
import projetlong.Exam.AffichageExamenQCM;

import projetlong.Exam.ExamenQCM;
import projetlong.Exam.ExerciceQCM;

public class Student extends JFrame implements ActionListener, WindowStateListener {
    JPanel sidePanel, rightPanel, buttonsPanel;
    JLabel usericon, lblUsername, lblNotifications;
    JButton viewProfileBtn, logoutBtn;
    JButton b1, b2, b3, b4, b5, b6, b7,b8, inboxBtn, sentboxBtn;
    BufferedImage bufferedImage = null;
    int identifiant;
    GestionneurData gestionnaire;
    int previousUnreadCount = 0; // Pour suivre le nombre précédent de messages non lus

    public Student(int iban) {
        super("Espace Étudiant");
        setLayout(new BorderLayout());
        setSize(1300, 720); // Augmenter la taille pour plus d'espace
        setLocation(35, 30);

        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/systemIcon.png"));
        setIconImage(icon.getImage());
        this.addWindowStateListener(this);

        gestionnaire = new GestionneurData("donneesUtilisateurs.properties");

        sidePanel = new JPanel();
        sidePanel.setLayout(null);
        sidePanel.setBackground(new Color(0, 26, 195));
        Dimension sidePanelSize = new Dimension(180, 720);
        sidePanel.setPreferredSize(sidePanelSize);
        add(sidePanel, BorderLayout.WEST);

        // Tentative de chargement des détails et de l'image de l'étudiant
        String firstName = null, lastName = null, gender = "";
        byte[] bytImage = null;
        try {
            firstName = gestionnaire.obtenirPropriete(iban, "student", "fname");
            lastName = gestionnaire.obtenirPropriete(iban, "student", "lname");
            gender = gestionnaire.obtenirPropriete(iban, "student", "gender");
            this.identifiant = iban;
            File file = new File(gestionnaire.obtenirPropriete(iban, "student", "picturePath"));
            bytImage = fileToByteArray(file);
        } catch (IOException e) {
            e.printStackTrace();
        }

        InputStream is = new ByteArrayInputStream(bytImage);
        try {
            bufferedImage = ImageIO.read(is);
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        usericon = new JLabel(resizeImage(bufferedImage));
        usericon.setBounds(42, 20, 96, 96);
        usericon.setHorizontalAlignment((int) CENTER_ALIGNMENT);
        sidePanel.add(usericon);

        lblUsername = new JLabel(firstName + " " + lastName);
        lblUsername.setFont(new Font(Font.SERIF, Font.BOLD, 20));
        lblUsername.setForeground(new Color(45, 255, 3));
        lblUsername.setBounds(20, 130, 150, 40);
        lblUsername.setHorizontalAlignment((int) CENTER_ALIGNMENT);
        sidePanel.add(lblUsername);

        // Ajouter l'étiquette de notification des messages non lus
        lblNotifications = new JLabel("0 nouveaux messages", JLabel.CENTER);
        lblNotifications.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        lblNotifications.setForeground(Color.RED);
        lblNotifications.setBounds(20, 170, 150, 20);
        sidePanel.add(lblNotifications);

        viewProfileBtn = new JButton("Voir Profil");
        styleButton(viewProfileBtn);
        viewProfileBtn.setBounds(30, 200, 120, 40);
        sidePanel.add(viewProfileBtn);

        logoutBtn = new JButton("Déconnexion");
        styleButton(logoutBtn);
        logoutBtn.setBounds(30, 600, 120, 40);
        sidePanel.add(logoutBtn);

        rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(Color.WHITE);
        add(rightPanel, BorderLayout.CENTER);

        JLabel mainTitle = new JLabel("Espace Étudiant");
        mainTitle.setHorizontalAlignment(JLabel.CENTER);
        mainTitle.setFont(new Font(Font.SERIF, Font.BOLD, 50));
        mainTitle.setBackground(new Color(0, 26, 195));
        mainTitle.setForeground(Color.WHITE);
        mainTitle.setOpaque(true);
        rightPanel.add(mainTitle, BorderLayout.NORTH);

        buttonsPanel = new JPanel();
        buttonsPanel.setLayout(null);
        rightPanel.add(buttonsPanel, BorderLayout.CENTER);

        JLabel buttonSectionTitle = new JLabel("Mon Compte");
        buttonSectionTitle.setFont(new Font(Font.SERIF, Font.BOLD, 25));
        buttonSectionTitle.setForeground(Color.BLACK);
        buttonSectionTitle.setBounds(20, 20, 150, 50);
        buttonsPanel.add(buttonSectionTitle);

        b1 = createButton("Gérer Compte", "ManageAccount.png", 250, 60);
        buttonsPanel.add(b1);

        b2 = createButton("Supprimer Compte", "DeleteAccount.png", 410, 60);
        buttonsPanel.add(b2);

        b3 = createButton("Consulter Compte", "viewAccount.png", 570, 60);
        buttonsPanel.add(b3);

        JLabel buttonSectionTitle2 = new JLabel("Opérations");
        buttonSectionTitle2.setFont(new Font(Font.SERIF, Font.BOLD, 25));
        buttonSectionTitle2.setForeground(Color.BLACK);
        buttonSectionTitle2.setBounds(20, 160, 225, 50);
        buttonsPanel.add(buttonSectionTitle2);

        b4 = createButton("Inscrire à un Cours", "addSubject.png", 250, 210);
        buttonsPanel.add(b4);

        b5 = createButton("Étudier Cours", "StartCourse.png", 410, 210);
        buttonsPanel.add(b5);

        b6 = createButton("Retirer Cours", "withdrawCourse.png", 570, 210);
        buttonsPanel.add(b6);

        b7 = createButton("Voir Participants", "participants.png", 250, 320);
        buttonsPanel.add(b7);


        b8 = createButton("Exam", "viewCourses.png", 410, 320);
        buttonsPanel.add(b8);

        inboxBtn = createIconButton("Boîte de Réception", "inbox.png", 950, 10);
        buttonsPanel.add(inboxBtn);

        sentboxBtn = createIconButton("Envoyer Message", "sentbox.png", 950, 150);
        buttonsPanel.add(sentboxBtn);

        setResizable(true);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setVisible(true);

        // Mise à jour du nombre de messages non lus
        updateUnreadMessages();

        // Ajouter un Timer pour vérifier régulièrement les nouveaux messages
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkForNewMessages();
            }
        });
        timer.start();
    }

    private void updateUnreadMessages() {
        int unreadCount = 0;
        GestionneurData messageGestionnaire = new GestionneurData("messages.properties");
        for (int i = 1; i <= messageGestionnaire.identifiantValableMsg(); i++) {
            String toID = messageGestionnaire.obtenirPropriete(i, "message", "to_ID");
            String isRead = messageGestionnaire.obtenirPropriete(i, "message", "read");
            if (toID != null && Integer.parseInt(toID) == this.identifiant && "no".equals(isRead)) {
                unreadCount++;
            }
        }
        lblNotifications.setText(unreadCount + " nouveaux messages");
    }

    private void checkForNewMessages() {
        int unreadCount = 0;
        GestionneurData messageGestionnaire = new GestionneurData("messages.properties");
        for (int i = 1; i <= messageGestionnaire.identifiantValableMsg(); i++) {
            String toID = messageGestionnaire.obtenirPropriete(i, "message", "to_ID");
            String isRead = messageGestionnaire.obtenirPropriete(i, "message", "read");
            if (toID != null && Integer.parseInt(toID) == this.identifiant && "no".equals(isRead)) {
                unreadCount++;
            }
        }
        if (unreadCount > previousUnreadCount) {
            JOptionPane.showMessageDialog(this, "Vous avez de nouveaux messages !");
            previousUnreadCount = unreadCount;
        }
        lblNotifications.setText(unreadCount + " nouveaux messages");
    }

    private JButton createButton(String text, String iconPath, int x, int y) {
        JButton button = new JButton(text, new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/" + iconPath)));
        button.setBounds(x, y, 130, 90);
        button.setHorizontalTextPosition(JButton.CENTER);
        button.setVerticalTextPosition(JButton.BOTTOM);
        button.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        button.setFocusPainted(false);
        button.addActionListener(this);
        return button;
    }

    private JButton createIconButton(String text, String iconPath, int x, int y) {
        JButton button = new JButton(text, new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/" + iconPath)));
        button.setBounds(x, y, 130, 125);
        button.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        button.setHorizontalTextPosition(JButton.CENTER);
        button.setVerticalTextPosition(JButton.BOTTOM);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setBorder(new LineBorder(Color.WHITE, 2));
        button.addActionListener(this);
        return button;
    }

    private void styleButton(JButton button) {
        button.setFont(new Font(Font.SERIF, Font.BOLD, 13));
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(new CompoundBorder(new LineBorder(Color.WHITE), new EmptyBorder(5, 15, 5, 15)));
        button.addActionListener(this);
    }

    private byte[] fileToByteArray(File file) throws IOException {
        FileInputStream fis = new FileInputStream(file);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[1024];
        for (int readNum; (readNum = fis.read(buf)) != -1; ) {
            bos.write(buf, 0, readNum);
        }
        fis.close();
        return bos.toByteArray();
    }

    public ImageIcon resizeImage(BufferedImage bufferedImage) {
        int width = bufferedImage.getWidth();
        BufferedImage circleBuffer = new BufferedImage(width, width, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = circleBuffer.createGraphics();
        g2.setClip(new Ellipse2D.Float(0, 0, width, width));
        g2.drawImage(bufferedImage, 0, 0, width, width, null);
        g2.dispose();
        ImageIcon icon = new ImageIcon(circleBuffer);
        Image i2 = icon.getImage().getScaledInstance(96, 96, Image.SCALE_DEFAULT);
        return new ImageIcon(i2);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        Object source = ae.getSource();
        if (source == b1) {
            new GererProfil();
        } else if (source == b2) {
            new SupprimerCompte(this.identifiant);
        } else if (source == b3) {
            new ConsulterProfil(this.identifiant);
        } else if (source == b4) {
            new EnrollCourse(this.identifiant);
        } else if (source == b5) {
            new StudyCours(this.identifiant);
        } else if (source == b6) {
            // Retirer Cours
        } else if (source == b7) {
            new Participants(this.identifiant);
        } else if (source == b8) {

            ExamenQCM examen = new ExamenQCM();
            examen.ajouterExercice(new ExerciceQCM("Est-ce que Java est un langage de programmation orienté objet ?", Arrays.asList("Oui", "Non"), "Oui"));
            examen.ajouterExercice(new ExerciceQCM("Est-ce que Java supporte l'héritage multiple via les classes ?",  Arrays.asList("Oui", "Non"), "Non"));
            examen.ajouterExercice(new ExerciceQCM("Est-ce que le mot-clé final en Java peut être utilisé pour déclarer des variables constantes ?",  Arrays.asList("Oui", "Non"), "Oui"));
            examen.ajouterExercice(new ExerciceQCM("Est-ce que le type int en Java peut contenir des valeurs décimales ?",  Arrays.asList("Oui", "Non"), "Non"));
    
            new AffichageExamenQCM(examen,this.identifiant);
        } else if (source == viewProfileBtn) {
            new StudentAccountDetails(identifiant);
        } else if (source == logoutBtn) {
            
            dispose();
        } else if (source == inboxBtn) {
            new Inbox(this.identifiant);
        } else if (source == sentboxBtn) {
            new ViewParticipants(this.identifiant);
        }
    }

    @Override
    public void windowStateChanged(WindowEvent e) {
        if ((e.getNewState() & Frame.MAXIMIZED_BOTH) == Frame.NORMAL) {
            // Gérer l'état normal
        } else if ((e.getNewState() & Frame.MAXIMIZED_BOTH) == Frame.MAXIMIZED_BOTH) {
            // Gérer l'état maximisé
        }
    }

    public static void main(String[] args) {
        new Student(1); //je teste :D
    }
}
