package projetlong;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import projetlong.Student.ConnexionEtudiant;

public class Login extends JFrame implements ActionListener {
    JPanel panel;
    JButton boutonConnexionEtudiant, boutonConnexionEnseignant, boutonConnexionAdmin;
    JLabel titre;

    public Login() {
        super("Connexion");
        setSize(400, 400);
        setLocation(550, 365);
        setLayout(new BorderLayout());

        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/systemIcon.png"));
        setIconImage(icon.getImage());

        panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(230, 230, 250));

        titre = new JLabel("Connectez-vous ici", JLabel.CENTER);
        titre.setFont(new Font("Arial", Font.BOLD, 24));
        titre.setBackground(new Color(70, 130, 180));
        titre.setForeground(Color.WHITE);
        titre.setOpaque(true);
        titre.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titre, BorderLayout.NORTH);

        boutonConnexionEtudiant = createStyledButton("Connexion Étudiant");
        boutonConnexionEnseignant = createStyledButton("Connexion Enseignant");
        boutonConnexionAdmin = createStyledButton("Connexion Admin");

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0); // Marges entre les boutons
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(boutonConnexionEtudiant, gbc);

        gbc.gridy++;
        panel.add(boutonConnexionEnseignant, gbc);

        gbc.gridy++;
        panel.add(boutonConnexionAdmin, gbc);

        // ajout au cadre
        add(panel, BorderLayout.CENTER);

        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(new CompoundBorder(
            new LineBorder(Color.WHITE, 2),
            new EmptyBorder(5, 15, 5, 15)
        ));
        button.addActionListener(this);
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == boutonConnexionEtudiant) {
            setVisible(false);
            new ConnexionEtudiant();
        } else if (ae.getSource() == boutonConnexionEnseignant) {
            setVisible(false);
            // Logique pour la connexion enseignant
        } else if (ae.getSource() == boutonConnexionAdmin) {
            setVisible(false);
            // Logique pour la connexion admin
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
