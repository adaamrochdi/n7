package projetlong.Student;

import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import projetlong.GestionneurData;

public class InscriptionEtudiant extends JFrame implements ActionListener, FocusListener {
    JPanel panneau;
    JTextField prenom, nom, email, nomUtilisateur;
    JPasswordField champMotDePasse;
    JButton boutonInscrire, boutonTelechargerPhoto;
    JRadioButton boutonRadioHomme, boutonRadioFemme;
    ButtonGroup groupeBoutonsRadio;
    JLabel validationPrenom, validationNom, validationEmail, validationNomUtilisateur, validationMotDePasse, labelPhotoProfil;
    FileInputStream fis = null;
    File fichier = null;
    Integer IndiceValidePourMoment;

    public InscriptionEtudiant() {
        super("Inscription Étudiant");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1014, 515);
        setLocation(230, 110);
        setResizable(false);
        panneau = new JPanel();
        panneau.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(panneau);
        panneau.setLayout(null);

        labelPhotoProfil = new JLabel();
        labelPhotoProfil.setIcon(new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/uploadPicIcon.png")));
        labelPhotoProfil.setBounds(456, 18, 96, 96);
        panneau.add(labelPhotoProfil);

        boutonTelechargerPhoto = new JButton("Télécharger");
        boutonTelechargerPhoto.setBounds(470, 120, 75, 23);
        boutonTelechargerPhoto.addActionListener(this);
        panneau.add(boutonTelechargerPhoto);

        JLabel labelPrenom = new JLabel("Prénom");
        labelPrenom.setFont(new Font("Tahoma", Font.PLAIN, 20));
        labelPrenom.setBounds(58, 152, 99, 43);
        panneau.add(labelPrenom);

        JLabel labelNom = new JLabel("Nom");
        labelNom.setFont(new Font("Tahoma", Font.PLAIN, 20));
        labelNom.setBounds(58, 243, 110, 29);
        panneau.add(labelNom);

        JLabel labelEmail = new JLabel("Adresse Email");
        labelEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
        labelEmail.setBounds(58, 324, 124, 36);
        panneau.add(labelEmail);

        validationPrenom = new JLabel();
        prenom = new JTextField();
        prenom.setFont(new Font("Tahoma", Font.PLAIN, 32));
        prenom.setBounds(214, 151, 228, 50);
        prenom.addFocusListener(this);
        validationPrenom.setBounds(214, 205, 150, 10);
        panneau.add(validationPrenom);
        panneau.add(prenom);
        prenom.setColumns(10);

        validationNom = new JLabel();
        nom = new JTextField();
        nom.setFont(new Font("Tahoma", Font.PLAIN, 32));
        nom.setBounds(214, 235, 228, 50);
        nom.addFocusListener(this);
        validationNom.setBounds(214, 289, 150, 10);
        panneau.add(validationNom);
        panneau.add(nom);
        nom.setColumns(10);

        validationEmail = new JLabel();
        email = new JTextField();
        email.setFont(new Font("Tahoma", Font.PLAIN, 32));
        email.setBounds(214, 320, 228, 50);
        email.addFocusListener(this);
        validationEmail.setBounds(214, 374, 150, 10);
        panneau.add(validationEmail);
        panneau.add(email);
        email.setColumns(10);

        validationNomUtilisateur = new JLabel();
        nomUtilisateur = new JTextField();
        nomUtilisateur.setFont(new Font("Tahoma", Font.PLAIN, 32));
        nomUtilisateur.setBounds(707, 151, 228, 50);
        nomUtilisateur.addFocusListener(this);
        validationNomUtilisateur.setBounds(707, 205, 150, 10);
        panneau.add(validationNomUtilisateur);
        panneau.add(nomUtilisateur);
        nomUtilisateur.setColumns(10);

        JLabel labelNomUtilisateur = new JLabel("Nom d'utilisateur");
        labelNomUtilisateur.setFont(new Font("Tahoma", Font.PLAIN, 20));
        labelNomUtilisateur.setBounds(542, 159, 150, 29);
        panneau.add(labelNomUtilisateur);

        JLabel labelMotDePasse = new JLabel("Mot de passe");
        labelMotDePasse.setFont(new Font("Tahoma", Font.PLAIN, 20));
        labelMotDePasse.setBounds(542, 245, 120, 24);
        panneau.add(labelMotDePasse);

        champMotDePasse = new JPasswordField();
        champMotDePasse.setFont(new Font("Tahoma", Font.PLAIN, 32));
        champMotDePasse.setBounds(707, 235, 228, 50);
        panneau.add(champMotDePasse);

        JLabel labelGenre = new JLabel("Genre");
        labelGenre.setFont(new Font("Tahoma", Font.PLAIN, 20));
        labelGenre.setBounds(542, 331, 99, 24);
        panneau.add(labelGenre);

        boutonRadioHomme = new JRadioButton("Homme");
        boutonRadioFemme = new JRadioButton("Femme");
        groupeBoutonsRadio = new ButtonGroup();

        boutonRadioHomme.setFont(new Font("Tahoma", Font.PLAIN, 25));
        boutonRadioHomme.setBounds(707, 321, 110, 50);
        boutonRadioHomme.setActionCommand("Homme");
        panneau.add(boutonRadioHomme);

        boutonRadioFemme.setFont(new Font("Tahoma", Font.PLAIN, 25));
        boutonRadioFemme.setBounds(825, 321, 120, 50);
        boutonRadioFemme.setActionCommand("Femme");
        panneau.add(boutonRadioFemme);

        groupeBoutonsRadio.add(boutonRadioHomme);
        groupeBoutonsRadio.add(boutonRadioFemme);

        boutonInscrire = new JButton("S'inscrire");
        boutonInscrire.setBounds(410, 400, 228, 60);
        boutonInscrire.addActionListener(this);
        panneau.add(boutonInscrire);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == boutonTelechargerPhoto) {
            JFileChooser choixFichier = new JFileChooser();
            choixFichier.showOpenDialog(null);
            fichier = choixFichier.getSelectedFile();
            if (fichier != null) {
                String cheminFichier = fichier.getAbsolutePath();
                try {
                    File image = new File(cheminFichier);
                    fis = new FileInputStream(image);
                    labelPhotoProfil.setIcon(redimensionnerImage(cheminFichier));
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        } else if (ae.getSource() == boutonInscrire) {
            if (fichier == null) {
                JOptionPane.showMessageDialog(this, "Veuillez télécharger une image de profil.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String emailText = email.getText();
            if (!isValidEmail(emailText)) {
                JOptionPane.showMessageDialog(this, "Veuillez entrer une adresse email valide (exemple : test@quelquechose.com).", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Détection du genre
            String genre = "";
            if (boutonRadioFemme.isSelected()) {
                genre = "femme";
            } else if (boutonRadioHomme.isSelected()) {
                genre = "homme";
            }

            GestionneurData gestionnaire = new GestionneurData("donneesUtilisateurs.properties");
            IndiceValidePourMoment = gestionnaire.identifiantValable();

            // Définition des propriétés de l'étudiant
            gestionnaire.definirPropriete(IndiceValidePourMoment, "student", "fname", prenom.getText());
            gestionnaire.definirPropriete(IndiceValidePourMoment, "student", "lname", nom.getText());
            gestionnaire.definirPropriete(IndiceValidePourMoment, "student", "email", emailText);
            gestionnaire.definirPropriete(IndiceValidePourMoment, "student", "username", nomUtilisateur.getText());
            gestionnaire.definirPropriete(IndiceValidePourMoment, "student", "password", new String(champMotDePasse.getPassword()));
            gestionnaire.definirPropriete(IndiceValidePourMoment, "student", "gender", genre);
            gestionnaire.definirPropriete(IndiceValidePourMoment, "student", "registrationDate", "2024");
            gestionnaire.definirPropriete(IndiceValidePourMoment, "student", "score", "0");
            gestionnaire.definirPropriete(IndiceValidePourMoment, "student", "lastLogin", "2024");
            gestionnaire.definirPropriete(IndiceValidePourMoment, "student", "picturePath", fichier.getAbsolutePath());
            JOptionPane.showMessageDialog(null, "Inscription réussie");
        }
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public ImageIcon redimensionnerImage(String cheminImage) {
        BufferedImage imageTampon = null;
        try {
            imageTampon = ImageIO.read(new File(cheminImage));
        } catch (IOException ex) {
            Logger.getLogger(InscriptionEtudiant.class.getName()).log(Level.SEVERE, null, ex);
        }
        int largeur = imageTampon.getWidth();
        BufferedImage imageCirculaire = new BufferedImage(largeur, largeur, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = imageCirculaire.createGraphics();
        g2.setClip(new Ellipse2D.Float(0, 0, largeur, largeur));
        g2.drawImage(imageTampon, 0, 0, largeur, largeur, null);
        ImageIcon icone = new ImageIcon(imageCirculaire);
        Image imageRedimensionnee = icone.getImage().getScaledInstance(96, 96, Image.SCALE_DEFAULT);
        ImageIcon iconeRedimensionnee = new ImageIcon(imageRedimensionnee);
        return iconeRedimensionnee;
    }

    @Override
    public void focusGained(FocusEvent e) {
        // Gestion du focus ici
    }

    @Override
    public void focusLost(FocusEvent e) {
        // Gestion de la perte de focus ici
    }

    public static void main(String[] args) {
        new InscriptionEtudiant();
    }
}
