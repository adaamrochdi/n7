package projetlong.Student;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import projetlong.GestionneurData;

public class StudyCours extends JFrame implements ActionListener {
    JLabel title, themeCbLbl;
    JPanel mainPanel, coursePanel;
    JScrollPane scrollPane;
    JComboBox<String> themesCb;
    GestionneurData coursGestionnaire;
    GestionneurData etudiantGestionnaire;
    int studentId;

    public StudyCours(int studentId) {
        super("Étudier les Cours");
        this.studentId = studentId;
        coursGestionnaire = new GestionneurData("Cours.properties");
        etudiantGestionnaire = new GestionneurData("donneesUtilisateurs.properties");
        setLayout(new BorderLayout());

        title = new JLabel("Étudier les Cours", JLabel.CENTER);
        title.setFont(new Font(Font.SERIF, Font.BOLD, 26));
        title.setBackground(new Color(70, 130, 180));
        title.setForeground(Color.WHITE);
        title.setOpaque(true);
        title.setBorder(new EmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        add(mainPanel, BorderLayout.CENTER);

        JPanel filterPanel = new JPanel();
        filterPanel.setBackground(new Color(245, 245, 245));
        filterPanel.setBorder(BorderFactory.createTitledBorder("Filtres"));
        filterPanel.setLayout(new BorderLayout(10, 10));

        themeCbLbl = new JLabel("Sélectionner un thème");
        themeCbLbl.setFont(new Font(Font.SERIF, Font.BOLD, 16));
        themeCbLbl.setBorder(new EmptyBorder(0, 10, 0, 0));
        filterPanel.add(themeCbLbl, BorderLayout.WEST);

        themesCb = new JComboBox<>(coursGestionnaire.obtenirCoursThemes());
        themesCb.setSelectedIndex(-1);
        themesCb.addActionListener(this);
        themesCb.setFont(new Font(Font.SERIF, Font.PLAIN, 16));
        filterPanel.add(themesCb, BorderLayout.CENTER);

        mainPanel.add(filterPanel, BorderLayout.NORTH);

        coursePanel = new JPanel(new GridLayout(0, 4, 20, 20));
        coursePanel.setBackground(Color.WHITE);
        scrollPane = new JScrollPane(coursePanel);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Cours Disponibles"));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(900, 700);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadCourses(String selectedTheme) {
        coursePanel.removeAll();
        List<String> coursePaths = getCoursesByTheme(selectedTheme);
        String enrolledCourses = etudiantGestionnaire.obtenirCoursSuivis(studentId);
        if (enrolledCourses != null && !enrolledCourses.isEmpty()) {
            String[] enrolledCourseIds = enrolledCourses.split(",");
            for (String path : coursePaths) {
                String title = new File(path).getName();
                title = title.substring(0, title.lastIndexOf(".")); // Remove extension
                addCourseToPanel(title, path);
            }
        }
        coursePanel.revalidate();
        coursePanel.repaint();
    }

    private List<String> getCoursesByTheme(String theme) {
        List<String> courses = new ArrayList<>();
        for (int i = 1; i <= coursGestionnaire.identifiantValableCours(); i++) {
            if (theme.equals(coursGestionnaire.obtenirPropriete(i, "cours", "theme"))) {
                String coursePath = coursGestionnaire.obtenirCoursPath(i);
                courses.add(coursePath);
            }
        }
        return courses;
    }

    private void addCourseToPanel(String title, String path) {
        JPanel courseItem = new JPanel(new BorderLayout(5, 5));
        courseItem.setBackground(Color.WHITE);
        courseItem.setBorder(new CompoundBorder(
            new LineBorder(new Color(192, 192, 192), 1),
            new EmptyBorder(10, 10, 10, 10)
        ));

        ImageIcon pdfIcon = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/pdf.png"));
        Image pdfImage = pdfIcon.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
        JButton pdfButton = new JButton(new ImageIcon(pdfImage));
        pdfButton.setBackground(Color.WHITE);
        pdfButton.setBorder(null);
        pdfButton.setToolTipText(path);
        pdfButton.addActionListener(this);

        JLabel courseLabel = new JLabel(title, JLabel.CENTER);
        courseLabel.setFont(new Font(Font.SERIF, Font.BOLD, 14)); // Bold font

        courseItem.add(courseLabel, BorderLayout.NORTH);
        courseItem.add(pdfButton, BorderLayout.CENTER);
        coursePanel.add(courseItem);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == themesCb) {
            String selectedTheme = (String) themesCb.getSelectedItem();
            if (selectedTheme != null) {
                loadCourses(selectedTheme);
            }
        } else {
            JButton source = (JButton) ae.getSource();
            String path = source.getToolTipText();
            if (path != null) {
                try {
                    Desktop.getDesktop().open(new File(path));
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Erreur lors de l'ouverture du fichier : " + ex.getMessage());
                }
            }
        }
    }

    public static void main(String[] args) {
    }
}
