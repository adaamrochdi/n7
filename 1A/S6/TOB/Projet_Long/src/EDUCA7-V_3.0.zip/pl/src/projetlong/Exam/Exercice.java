package projetlong.Exam;


/** L'interface Exercice définit les fonctionnalités communes à 
 * tous les types d'exercices dans le système d'enseignement en ligne.
  *
  * @author	Zahaf Hedi
  * @version	version : 1.0
  */
public interface Exercice {
	/** Obtenir l'ennancer d'un exercice.
	 * @return lenancer.  */
	String obtenirEnonce();
	
	/** Verifier la reponse.
	 * @return bool correspandant a si la reponse est juste ou fausse.  */
	boolean verifierReponse(String reponse);
	
	/** Donne la reponse a l'exercice.
	 * @return reponse de l'excercice.  */
	String donnerReponse(String exercice);
}
