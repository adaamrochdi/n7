package projetlong.Student;

import projetlong.GestionneurData;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ConsulterProfil extends JFrame {
    private JPanel panneau;
    private JLabel prenomLabel, nomLabel, emailLabel, nomUtilisateurLabel, photoLabel;
    private JButton badgeButton;
    Integer IndiceValidePourMoment;

    public ConsulterProfil(int iban) {
        super("Consulter Profil Étudiant");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 450);
        setLocationRelativeTo(null);
        panneau = new JPanel();
        panneau.setBorder(new EmptyBorder(15, 15, 15, 15));
        panneau.setLayout(null);
        panneau.setBackground(new Color(240, 248, 255)); // Couleur de fond douce
        setContentPane(panneau);

        GestionneurData gestionnaire = new GestionneurData("donneesUtilisateurs.properties");
        IndiceValidePourMoment = iban; // Utiliser le dernier identifiant valide

        String prenom = gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "fname");
        String nom = gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "lname");
        String email = gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "email");
        String nomUtilisateur = gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "username");
        String cheminImage = gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "picturePath");
        int score = Integer.parseInt(gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "score"));

        JLabel titreLabel = new JLabel("Profil Étudiant");
        titreLabel.setFont(new Font("Tahoma", Font.BOLD, 28));
        titreLabel.setForeground(new Color(25, 25, 112)); // Bleu marine
        titreLabel.setBounds(200, 10, 250, 30);
        panneau.add(titreLabel);

        photoLabel = new JLabel();
        photoLabel.setBounds(200, 50, 100, 100);
        photoLabel.setBorder(new LineBorder(new Color(25, 25, 112), 2, true)); // Encadrer l'image
        if (cheminImage != null && !cheminImage.isEmpty()) {
            try {
                BufferedImage bufferedImage = ImageIO.read(new File(cheminImage));
                photoLabel.setIcon(redimensionnerImage(bufferedImage));
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            photoLabel.setIcon(new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/defaultProfilePic.png")));
        }
        panneau.add(photoLabel);

        // Ajouter le badgeButton à côté de la photo de profil
        badgeButton = new JButton();
        badgeButton.setBounds(310, 50, 100, 100); // Ajuster la taille pour correspondre à celle de la photo
        badgeButton.setBorder(BorderFactory.createLineBorder(new Color(25, 25, 112), 2, true)); // Encadrer le badge
        badgeButton.setContentAreaFilled(false);
        badgeButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panneau.add(badgeButton);
        afficherBadge(score);

        prenomLabel = new JLabel("Prénom: " + prenom);
        prenomLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
        prenomLabel.setForeground(new Color(25, 25, 112));
        prenomLabel.setBounds(50, 180, 500, 30);
        panneau.add(prenomLabel);

        nomLabel = new JLabel("Nom: " + nom);
        nomLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
        nomLabel.setForeground(new Color(25, 25, 112));
        nomLabel.setBounds(50, 220, 500, 30);
        panneau.add(nomLabel);

        emailLabel = new JLabel("Email: " + email);
        emailLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
        emailLabel.setForeground(new Color(25, 25, 112));
        emailLabel.setBounds(50, 260, 500, 30);
        panneau.add(emailLabel);

        nomUtilisateurLabel = new JLabel("Nom d'utilisateur: " + nomUtilisateur);
        nomUtilisateurLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
        nomUtilisateurLabel.setForeground(new Color(25, 25, 112));
        nomUtilisateurLabel.setBounds(50, 300, 500, 30);
        panneau.add(nomUtilisateurLabel);

        // Ajouter un effet de survol dynamique aux étiquettes
        ajouterEffetSurvol(prenomLabel);
        ajouterEffetSurvol(nomLabel);
        ajouterEffetSurvol(emailLabel);
        ajouterEffetSurvol(nomUtilisateurLabel);

        setVisible(true);
    }

    private void afficherBadge(int score) {
        String cheminBadge = null;
        if (score >= 90) {
            cheminBadge = "projetlong/badges/hard.png";
        } else if (score >= 50 && score < 90) {
            cheminBadge = "projetlong/badges/mid.png";
        } else if (score >= 0 && score < 50) {
            cheminBadge = "projetlong/badges/lv1.png";
        }

        if (cheminBadge != null) {
            try {
                ImageIcon badgeIcon = new ImageIcon(ClassLoader.getSystemResource(cheminBadge));
                badgeButton.setIcon(new ImageIcon(badgeIcon.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT)));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private ImageIcon redimensionnerImage(BufferedImage bufferedImage) {
        int largeur = bufferedImage.getWidth();
        BufferedImage imageCirculaire = new BufferedImage(largeur, largeur, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = imageCirculaire.createGraphics();
        g2.setClip(new Ellipse2D.Float(0, 0, largeur, largeur));
        g2.drawImage(bufferedImage, 0, 0, largeur, largeur, null);
        ImageIcon icone = new ImageIcon(imageCirculaire);
        Image imageRedimensionnee = icone.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        return new ImageIcon(imageRedimensionnee);
    }

    private void ajouterEffetSurvol(JLabel label) {
        label.addMouseListener(new java.awt.event.MouseAdapter() {
            Color couleurOriginale = label.getForeground();

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                label.setForeground(new Color(100, 149, 237)); // Couleur bleu clair sur survol
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                label.setForeground(couleurOriginale);
            }
        });
    }

    public static void main(String[] args) {
        new ConsulterProfil(1);
    }
}
