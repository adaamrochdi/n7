package projetlong.Student;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.border.LineBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.BorderFactory;
import projetlong.GestionneurData;

public class ViewParticipants extends JFrame implements ActionListener {
    JLabel title, courseCbLbl;
    JPanel middlePanel;
    JScrollPane scroll;
    JTable table;
    DefaultTableModel model;
    JButton contactBtn;
    JButton showContactsBtn;
    GestionneurData gestionnaire;
    int iden;

    public ViewParticipants(int iban) {
        super("Voir les Participants");
        setLayout(new BorderLayout());

        gestionnaire = new GestionneurData("donneesUtilisateurs.properties");

        title = new JLabel("Participants", JLabel.CENTER);
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        title.setBackground(new Color(70, 130, 180));
        title.setForeground(Color.WHITE);
        title.setOpaque(true);
        title.setBorder(new EmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        middlePanel = new JPanel();
        middlePanel.setLayout(null);
        middlePanel.setBackground(Color.WHITE);
        add(middlePanel, BorderLayout.CENTER);

        model = new DefaultTableModel(new Object[]{"ID", "Nom", "Email", "Dernière Connexion", "Rôle"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        JTableHeader header = table.getTableHeader();
        header.setBackground(new Color(173, 216, 230));
        header.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        table.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        table.setRowHeight(30);
        table.setSelectionBackground(new Color(173, 216, 230));
        table.setSelectionForeground(Color.BLACK);
        table.setGridColor(new Color(192, 192, 192));
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(20, 95, 550, 245);
        pane.setBorder(BorderFactory.createLineBorder(new Color(192, 192, 192), 1));
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent event) {
                if (!event.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                    String role = table.getValueAt(table.getSelectedRow(), 4).toString();
                    contactBtn.setEnabled(!role.equals("Teacher"));
                }
            }
        });
        middlePanel.add(pane);

        contactBtn = new JButton("Contacter");
        styleButton(contactBtn);
        contactBtn.setToolTipText("Cliquer pour envoyer un message au participant sélectionné.");
        contactBtn.setEnabled(false); // Désactivé initialement
        add(contactBtn, BorderLayout.SOUTH);

        showContactsBtn = new JButton("Afficher les Contacts");
        styleButton(showContactsBtn);
        showContactsBtn.setToolTipText("Cliquer pour actualiser la liste des participants.");
        add(showContactsBtn, BorderLayout.NORTH);

        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 450);
        setLocation(420, 260);
        setVisible(true);
        this.iden = iban;
    }

    private void styleButton(JButton button) {
        button.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(Color.WHITE),
            new EmptyBorder(5, 15, 5, 15)
        ));
        button.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == showContactsBtn) {
            // Effacer tous les enregistrements du JTable
            model.setRowCount(0);

            // Ajouter des étudiants
            for (int i = 1; i < gestionnaire.identifiantValable(); i++) {
                String username = gestionnaire.obtenirPropriete(i, "student", "username");
                if (username != null) {
                    String firstName = gestionnaire.obtenirPropriete(i, "student", "fname");
                    String lastName = gestionnaire.obtenirPropriete(i, "student", "lname");
                    String email = gestionnaire.obtenirPropriete(i, "student", "email");
                    String lastLogin = gestionnaire.obtenirPropriete(i, "student", "last_login");
                    String role = "Student";

                    model.addRow(new Object[]{i, firstName + " " + lastName, email, lastLogin, role});
                }
            }
        } else if (ae.getSource() == contactBtn) {
            // Vérifier la ligne sélectionnée d'abord
            if (table.getSelectedRow() != -1) {
                int selectedRow = table.getSelectedRow();
                int selectedID = (int) table.getValueAt(selectedRow, 0);
                String selectedName = (String) table.getValueAt(selectedRow, 1);
                new Message(this.iden, selectedName, selectedID);
            }
        }
    }

    public static void main(String[] args) {
      
    }
}
