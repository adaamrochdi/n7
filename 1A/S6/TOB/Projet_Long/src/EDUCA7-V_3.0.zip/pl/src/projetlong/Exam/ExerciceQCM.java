package projetlong.Exam;

import java.util.List;

public class ExerciceQCM implements Exercice {
    private String enonce;
    private List<String> options;
    private String reponseCorrecte;

    public ExerciceQCM(String enonce, List<String> options, String reponseCorrecte) {
        this.enonce = enonce;
        this.options = options;
        this.reponseCorrecte = reponseCorrecte;
    }

    @Override
    public String obtenirEnonce() {
        return this.enonce;
    }

    @Override
    public boolean verifierReponse(String reponse) {
        return this.reponseCorrecte.equals(reponse);
    }

    @Override
    public String donnerReponse(String exercice) {
        return this.reponseCorrecte;
    }
    
    public List<String> getoptions() {
    	return this.options;
    }
    // A Faire : - Cree une nouvelle classe qui pourrai regrouper plusieur exercice dans une liste
    //           
}
