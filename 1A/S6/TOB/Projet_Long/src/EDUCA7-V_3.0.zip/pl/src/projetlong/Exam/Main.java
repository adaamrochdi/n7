package projetlong.Exam;

import java.util.Arrays;

import projetlong.GestionneurData;

public class Main {
    /**
     * @param args
     */
    public static void main(String[] args) {
        // Lancer l'interface de création d'examens
        CreationExamenQCM creationExamenQCM = new CreationExamenQCM();

        // Utiliser un WindowListener pour détecter la fermeture de la fenêtre
        creationExamenQCM.frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                ExamenQCM examen = creationExamenQCM.getExamenQCM();
                if (examen != null) {
                    GestionneurData os = new GestionneurData("donneesUtilisateurs.properties");


                    new AffichageExamenQCM(examen,os.identifiantValable()-1);
                }
            }
        });
    }
}
