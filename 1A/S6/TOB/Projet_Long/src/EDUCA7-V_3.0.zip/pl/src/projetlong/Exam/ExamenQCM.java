package projetlong.Exam;

import java.util.List;
import java.util.ArrayList;

public class ExamenQCM implements Examen {
    private List<ExerciceQCM> exercices;

    public ExamenQCM() {
        this.exercices = new ArrayList<>();
    }

    @Override
    public void ajouterExercice(Exercice exercice) {
        if (exercice instanceof ExerciceQCM) {
            exercices.add((ExerciceQCM) exercice);
        } else {
            throw new IllegalArgumentException("L'exercice doit être de type ExerciceQCM");
        }
    }

    @Override
    public void supprimerExercice(Exercice exercice) {
        exercices.remove(exercice);
    }

    @Override
    public List<Exercice> obtenirExercices() {
        return new ArrayList<Exercice>(exercices);
    }

    public int NBExercices() {
        return exercices.size();
    }
    

}
