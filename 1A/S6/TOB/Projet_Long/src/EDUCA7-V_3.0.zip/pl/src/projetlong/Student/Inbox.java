package projetlong.Student;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import projetlong.GestionneurData;

public class Inbox extends JFrame implements ActionListener, ListSelectionListener {
    JList<String> messagesList;
    DefaultListModel<String> listModel;
    JLabel title, messageLbl;
    JPanel mainPanel;
    JTextArea messageTxt;
    JButton replyBtn, deleteBtn;
    JScrollPane scroll1, scroll2;
    String[][] messagesListData;
    int currentFromUserID, currentMessageID;
    String currentFromUserName;
    GestionneurData messageGestionnaire;
    int id;

    public Inbox(int idd) {
        super("Boîte de Réception");
        this.id = idd;  // Assigner l'identifiant de l'utilisateur courant
        setLayout(new BorderLayout());

        messageGestionnaire = new GestionneurData("messages.properties");

        title = new JLabel("Boîte de Réception");
        title.setHorizontalAlignment(JLabel.CENTER);
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        title.setBackground(new Color(70, 130, 180));
        title.setForeground(Color.WHITE);
        title.setOpaque(true);
        title.setBorder(new EmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(Color.WHITE);
        add(mainPanel, BorderLayout.CENTER);

        listModel = new DefaultListModel<>();
        messagesList = new JList<>(listModel);
        messagesList.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        messagesList.setFixedCellHeight(40);
        messagesList.setFixedCellWidth(150);
        messagesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        messagesList.addListSelectionListener(this);
        scroll1 = new JScrollPane(messagesList);
        scroll1.setBounds(50, 50, 600, 220);
        scroll1.setBorder(new LineBorder(new Color(192, 192, 192), 1));
        mainPanel.add(scroll1);

        messageLbl = new JLabel("Message");
        messageLbl.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        messageLbl.setBounds(30, 270, 100, 30);
        mainPanel.add(messageLbl);

        messageTxt = new JTextArea();
        messageTxt.setLineWrap(true);
        messageTxt.setWrapStyleWord(true);
        messageTxt.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        messageTxt.setEditable(false);
        messageTxt.setBorder(new CompoundBorder(
            new LineBorder(new Color(192, 192, 192), 1),
            new EmptyBorder(10, 10, 10, 10)
        ));
        scroll2 = new JScrollPane(messageTxt);
        scroll2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scroll2.setBounds(30, 310, 600, 210);
        mainPanel.add(scroll2);

        replyBtn = new JButton("Répondre");
        styleButton(replyBtn);
        replyBtn.setEnabled(false);
        replyBtn.setBounds(510, 530, 120, 40);
        mainPanel.add(replyBtn);

        deleteBtn = new JButton("Supprimer");
        styleButton(deleteBtn);
        deleteBtn.setEnabled(false);
        deleteBtn.setBounds(50, 530, 120, 40);
        mainPanel.add(deleteBtn);

        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(700, 700);
        setLocation(385, 100);
        setVisible(true);
        loadMessages();
    }

    private void styleButton(JButton button) {
        button.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(Color.WHITE),
            new EmptyBorder(5, 15, 5, 15)
        ));
        button.addActionListener(this);
    }

    public void loadMessages() {
        int currentUserID = this.id;
        int rowCount = 0;
        System.err.println((messageGestionnaire.identifiantValableMsg()));

        // Compter les messages pour l'utilisateur courant
        for (int i = 1; i <= messageGestionnaire.identifiantValableMsg(); i++) {
            String toID = messageGestionnaire.obtenirPropriete(i, "message", "to_ID");
            if (toID != null && Integer.parseInt(toID) == currentUserID) {
                rowCount++;
            }
        }
        System.err.println(rowCount);

        messagesListData = new String[rowCount][6];
        int i = 0;
        GestionneurData gestionneurutilisateur = new GestionneurData("donneesUtilisateurs.properties");

        for (int j = 1; j <= messageGestionnaire.identifiantValableMsg(); j++) {
            String toID = messageGestionnaire.obtenirPropriete(j, "message", "to_ID");
            if (toID != null && Integer.parseInt(toID) == currentUserID) {
                String messageID = String.valueOf(j);
                String timeStamp = messageGestionnaire.obtenirPropriete(j, "message", "timestamp");
                String fromID = messageGestionnaire.obtenirPropriete(j, "message", "from_ID");
                String messageContent = messageGestionnaire.obtenirPropriete(j, "message", "content");
                String fromFirstName = gestionneurutilisateur.obtenirPropriete(Integer.parseInt(fromID), "student", "fname");
                String fromLastName = gestionneurutilisateur.obtenirPropriete(Integer.parseInt(fromID), "student", "lname");
                String fromUserName = fromFirstName + " " + fromLastName;
                System.out.println(messageID);
                messagesListData[i][0] = messageID;
                messagesListData[i][1] = timeStamp;
                messagesListData[i][2] = fromID;
                messagesListData[i][3] = messageContent;
                messagesListData[i][4] = fromUserName;

                StringBuilder elementStr = new StringBuilder();
                elementStr.append("<html><pre><b>");
                elementStr.append(String.format("%s \t\t\t %s", "De : " + fromUserName, "À : " + timeStamp));
                elementStr.append("</b></pre></html>");
                listModel.addElement(elementStr.toString());
                messagesListData[i][5] = String.valueOf(i);
                i++;
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == replyBtn) {
            new Message(this.id, currentFromUserName, currentFromUserID);
        } else if (e.getSource() == deleteBtn) {
            try {
                String messageIDStr = String.valueOf(currentMessageID);
                messageGestionnaire.definirPropriete(currentMessageID, "message", "deleted_by_" + this.id, "true");
                JOptionPane.showMessageDialog(null, "Message supprimé !");
                dispose();
                new Inbox(this.id);
            } catch (HeadlessException exception) {
                exception.printStackTrace();
            }
        }
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        int index = messagesList.getSelectedIndex();
        for (String[] messagesData : messagesListData) {
            if (index == Integer.parseInt(messagesData[5])) {
                messageTxt.setText(messagesData[3]);
                currentFromUserID = Integer.parseInt(messagesData[2]);
                currentFromUserName = messagesData[4];
                currentMessageID = Integer.parseInt(messagesData[0]);
                replyBtn.setEnabled(true);
                deleteBtn.setEnabled(true);

                // Marquer le message comme lu
                messageGestionnaire.definirPropriete(currentMessageID, "message", "read", "yes");
            }
        }
    }

    public static void main(String[] args) {
        // Utiliser l'ID 2 pour tester les messages pour l'utilisateur avec l'ID 2
    }
}
