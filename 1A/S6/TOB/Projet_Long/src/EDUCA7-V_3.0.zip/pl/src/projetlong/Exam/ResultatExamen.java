package projetlong.Exam;

public class ResultatExamen {
    private int totalQuestions;
    private int correctResponses;

    public ResultatExamen(int totalQuestions) {
        if (totalQuestions < 0) {
            throw new IllegalArgumentException("Le nombre total de questions ne peut pas être négatif.");
        }
        this.totalQuestions = totalQuestions;
        this.correctResponses = 0;
    }

    // Marquer une réponse correcte
    public void incrementerReponseCorrecte() {
        if (correctResponses < totalQuestions) {
            correctResponses++;
        }
    }

    // Obtenir le nombre de réponses correctes
    public int obtenirReponsesCorrectes() {
        return correctResponses;
    }

    // Obtenir le nombre total de questions
    public int obtenirTotalQuestions() {
        return totalQuestions;
    }

    // Obtenir le score en pourcentage
    public double obtenirScore() {
        if (totalQuestions == 0) {
            return 0.0;
        }
        return (double) correctResponses / totalQuestions * 100;
    }

    // Méthode pour afficher les résultats en détail
    @Override
    public String toString() {
        return String.format("Résultats: %d réponses correctes sur %d questions. Score: %.2f%%",
                correctResponses, totalQuestions, obtenirScore());
    }
}

