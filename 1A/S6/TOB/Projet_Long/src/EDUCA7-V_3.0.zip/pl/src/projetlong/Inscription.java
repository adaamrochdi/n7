package projetlong;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import projetlong.Student.InscriptionEtudiant;
import projetlong.Teacher.InscriptionEnseignant;

public class Inscription extends JFrame implements ActionListener {
    JPanel panneau;
    JButton boutonInscriptionEtudiant, boutonInscriptionEnseignant;
    JLabel titre;

    public Inscription() {
        super("Inscription");
        setSize(400, 300);
        setLocation(550, 365);
        setLayout(new BorderLayout());

        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/systemIcon.png"));
        setIconImage(icon.getImage());

        panneau = new JPanel();
        panneau.setLayout(new GridBagLayout());
        panneau.setBackground(new Color(230, 230, 250));

        titre = new JLabel("Inscrivez-vous ici", JLabel.CENTER);
        titre.setFont(new Font("Arial", Font.BOLD, 24));
        titre.setBackground(new Color(70, 130, 180));
        titre.setForeground(Color.WHITE);
        titre.setOpaque(true);
        titre.setBorder(new EmptyBorder(20, 0, 20, 0));
        add(titre, BorderLayout.NORTH);

        boutonInscriptionEtudiant = createStyledButton("Inscription Étudiant");
        boutonInscriptionEnseignant = createStyledButton("Inscription Enseignant");

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new java.awt.Insets(10, 0, 10, 0);
        panneau.add(boutonInscriptionEtudiant, gbc);

        gbc.gridy = 1;
        panneau.add(boutonInscriptionEnseignant, gbc);

        // Ajout au cadre
        add(panneau, BorderLayout.CENTER);

        // Paramètres du cadre
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(new CompoundBorder(
            new LineBorder(Color.WHITE, 2),
            new EmptyBorder(5, 15, 5, 15)
        ));
        button.addActionListener(this);
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == boutonInscriptionEtudiant) {
            setVisible(false);
            new InscriptionEtudiant();
        } else if (ae.getSource() == boutonInscriptionEnseignant) {
            setVisible(false);
            new InscriptionEnseignant();
        }
    }

    public static void main(String[] args) {
        new Inscription();
    }
}
