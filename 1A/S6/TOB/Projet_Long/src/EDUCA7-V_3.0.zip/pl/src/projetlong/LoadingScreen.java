package projetlong;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

public class LoadingScreen extends JFrame {
    JPanel mainPanel;
    JProgressBar loadingBar;
    JLabel backgroundPic, loadingLbl, percentageLbl;

    public LoadingScreen() {
        super("Educa7");
        setSize(1280, 720);
        setLocation(35, 30);
        setLayout(new BorderLayout());

        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/systemIcon.png"));
        setIconImage(icon.getImage());

        mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon background = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/background.png"));
                Image image = background.getImage();
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        mainPanel.setLayout(null);
        add(mainPanel, BorderLayout.CENTER);

        loadingLbl = new JLabel("En cours...");
        loadingLbl.setHorizontalAlignment(JLabel.LEFT);
        loadingLbl.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        loadingLbl.setForeground(Color.WHITE);
        loadingLbl.setBounds(5, 600, 250, 30);

        percentageLbl = new JLabel("0 %");
        percentageLbl.setHorizontalAlignment(JLabel.RIGHT);
        percentageLbl.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        percentageLbl.setForeground(Color.WHITE);
        percentageLbl.setBounds(1160, 600, 100, 30);

        mainPanel.add(loadingLbl);
        mainPanel.add(percentageLbl);

        loadingBar = new JProgressBar() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(Color.BLUE);
                String text = getString();
                int width = getWidth();
                int height = getHeight();
                g.drawString(text, (width - g.getFontMetrics().stringWidth(text)) / 2,
                        (height + g.getFontMetrics().getAscent() - g.getFontMetrics().getDescent()) / 2);
            }
        };
        loadingBar.setPreferredSize(new Dimension(1280, 20));
        loadingBar.setValue(0);
        loadingBar.setStringPainted(true);
        loadingBar.setForeground(Color.WHITE);
        add(loadingBar, BorderLayout.SOUTH);

        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        Run();
    }

    public void Run() {
        new SwingWorker<Void, Integer>() {
            @Override
            protected Void doInBackground() throws Exception {
                for (int i = 0; i <= 100; i++) {
                    Thread.sleep(100);
                    publish(i);

                    if (i == 10) {
                        loadingLbl.setText("Vérification des modules...");
                    } else if (i == 20) {
                        loadingLbl.setText("Vérification de la base des données...");
                    } else if (i == 50) {
                        loadingLbl.setText("Chargement des composants...");
                    } else if (i == 70) {
                        loadingLbl.setText("Initialisation réussie !");
                    } else if (i == 80) {
                        loadingLbl.setText("Bienvenue...");
                    } else if (i == 100) {
                        new Main();
                        dispose();
                    }
                }
                return null;
            }

            @Override
            protected void process(java.util.List<Integer> chunks) {
                int value = chunks.get(chunks.size() - 1);
                loadingBar.setValue(value);
                percentageLbl.setText(value + " %");
            }
        }.execute();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoadingScreen());
    }
}
