package projetlong.Exam;
import projetlong.GestionneurData;
import javax.swing.*;
import java.awt.*;
import java.util.Enumeration;

public class AffichageExamenQCM {

    private ExamenQCM examenQCM;
    private JFrame frame;
    private int indexExerciceActuel = 0;
    private ResultatExamen resultatExamen; 
    int identifiant;
    
    public AffichageExamenQCM(ExamenQCM examenQCM,int iden) {
        this.examenQCM = examenQCM;
    
        this.resultatExamen = new ResultatExamen(examenQCM.NBExercices());
        prepareGUI();

        this.identifiant = iden;

    }

    private void prepareGUI() {
        frame = new JFrame("Examen QCM");
        frame.setSize(500, 500);
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        afficherExercice();
        
    }

    private void afficherExercice() {
        frame.getContentPane().removeAll();

        ExerciceQCM exercice = (ExerciceQCM) examenQCM.obtenirExercices().get(indexExerciceActuel);
        JLabel enonceLabel = new JLabel(exercice.obtenirEnonce());
        frame.add(enonceLabel);

        ButtonGroup group = new ButtonGroup();
        JPanel panel = new JPanel(new GridLayout(0, 1));
        for (String option : exercice.getoptions()) {
            JRadioButton optionButton = new JRadioButton(option);
            group.add(optionButton);
            panel.add(optionButton);
        }

        JButton submitButton = new JButton("Soumettre");
        submitButton.addActionListener(e -> {
            Enumeration<AbstractButton> buttons = group.getElements();
            while (buttons.hasMoreElements()) {
                AbstractButton button = buttons.nextElement();
                if (button.isSelected() && exercice.verifierReponse(button.getText())) {
                    resultatExamen.incrementerReponseCorrecte();
                    JOptionPane.showMessageDialog(frame, "Réponse correcte!");
                } else if (button.isSelected()) {
                    JOptionPane.showMessageDialog(frame, "Réponse incorrecte.");
                }
            }

            indexExerciceActuel++;
            if (indexExerciceActuel < examenQCM.obtenirExercices().size()) {
                afficherExercice();
            } else {
                afficherResultat();
            }
        });

        frame.add(panel);
        frame.add(submitButton);
        frame.pack();
        frame.setVisible(true);
    }

    private void afficherResultat() {
        JOptionPane.showMessageDialog(frame, resultatExamen.toString(), "Résultat Final", JOptionPane.INFORMATION_MESSAGE);
        GestionneurData os = new GestionneurData("donneesUtilisateurs.properties");
        os.definirPropriete(this.identifiant,"student","score",String.valueOf((int)(resultatExamen.obtenirScore())));
        frame.dispose(); // Fermer la fenêtre après l'affichage des résultats
    }
}
