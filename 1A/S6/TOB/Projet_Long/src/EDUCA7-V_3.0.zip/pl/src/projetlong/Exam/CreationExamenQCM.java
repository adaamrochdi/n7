package projetlong.Exam;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class CreationExamenQCM {
    JFrame frame;
    private ExamenQCM examenQCM;
    private DefaultListModel<String> exerciceListModel;  // Changement du type pour afficher les noms des exercices
    private JList<String> exerciceList;  // Changement du type pour correspondre au modèle
    private JPanel panelCentre;

    public CreationExamenQCM() {
        examenQCM = new ExamenQCM();
        frame = new JFrame("Création Examen QCM");
        frame.setSize(1000, 400);
        frame.setLayout(new BorderLayout());
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Initialisation des composants de l'interface
        panelCentre = new JPanel();
        panelCentre.setLayout(new BoxLayout(panelCentre, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(panelCentre);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Liste des exercices
        exerciceListModel = new DefaultListModel<>();
        exerciceList = new JList<>(exerciceListModel);
        exerciceList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane listScrollPane = new JScrollPane(exerciceList);
        listScrollPane.setPreferredSize(new Dimension(200, 100));

        // Boutons pour ajouter et supprimer des exercices
        JButton ajouterExerciceButton = new JButton("Ajouter Exercice");
        JButton supprimerExerciceButton = new JButton("Supprimer Exercice");

        // Panel pour les boutons
        JPanel panelBoutons = new JPanel();
        panelBoutons.setLayout(new FlowLayout());
        panelBoutons.add(ajouterExerciceButton);
        panelBoutons.add(supprimerExerciceButton);

        // Ajout des composants au frame
        frame.add(listScrollPane, BorderLayout.WEST);
        frame.add(panelBoutons, BorderLayout.SOUTH);

        // Ajout d'un exercice initial
        ajouterExercice(panelCentre);

        // Action pour ajouter un exercice
        ajouterExerciceButton.addActionListener(e -> ajouterExercice(panelCentre));

        // Action pour supprimer un exercice
        supprimerExerciceButton.addActionListener(e -> {
            int selectedIndex = exerciceList.getSelectedIndex();
            if (selectedIndex != -1) {
                int response = JOptionPane.showConfirmDialog(frame, "Êtes-vous sûr de vouloir supprimer cet exercice ?", "Confirmer la suppression", JOptionPane.YES_NO_OPTION);
                if (response == JOptionPane.YES_OPTION) {
                    exerciceListModel.remove(selectedIndex);
                    panelCentre.remove(selectedIndex);
                    renommerExercices();  // Renommer les exercices après suppression
                    panelCentre.revalidate();
                    panelCentre.repaint();
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Veuillez sélectionner un exercice à supprimer.");
            }
        });

        // Fermer la fenêtre et créer l'examen
        JButton terminerButton = new JButton("Terminer");
        terminerButton.addActionListener(e -> {
            if (panelCentre.getComponentCount() > 0) {
                for (int i = 0; i < panelCentre.getComponentCount(); i++) {
                    JPanel panelExercice = (JPanel) panelCentre.getComponent(i);
                    JTextField enonceField = (JTextField) panelExercice.getComponent(1);
                    JPanel optionsPanel = (JPanel) panelExercice.getComponent(3);
                    List<String> options = new ArrayList<>();
                    String reponseCorrecte = null;

                    for (int j = 0; j < optionsPanel.getComponentCount(); j++) {
                        JPanel optionPanel = (JPanel) optionsPanel.getComponent(j);
                        JTextField optionField = (JTextField) optionPanel.getComponent(0);
                        JRadioButton radioButton = (JRadioButton) optionPanel.getComponent(1);

                        options.add(optionField.getText());
                        if (radioButton.isSelected()) {
                            reponseCorrecte = optionField.getText();
                        }
                    }

                    if (reponseCorrecte == null) {
                        JOptionPane.showMessageDialog(frame, "Veuillez sélectionner une réponse correcte pour chaque exercice.");
                        return;
                    }

                    ExerciceQCM exercice = new ExerciceQCM(enonceField.getText(), options, reponseCorrecte);
                    examenQCM.ajouterExercice(exercice);
                }
                
                // Afficher le pop-up avec le nombre d'exercices
                JOptionPane.showMessageDialog(frame, "Nombre d'exercices dans l'examen: " + examenQCM.NBExercices());

                frame.dispose();
            } else {
                JOptionPane.showMessageDialog(frame, "Veuillez ajouter au moins un exercice.");
            }
        });
        panelBoutons.add(terminerButton);

        frame.setVisible(true);
    }

    // Méthode pour ajouter un exercice
    private void ajouterExercice(JPanel panelCentre) {
        JPanel panelExercice = new JPanel();
        panelExercice.setLayout(new BoxLayout(panelExercice, BoxLayout.Y_AXIS));

        JLabel enonceLabel = new JLabel("Énoncé de l'exercice");
        JTextField enonceField = new JTextField();
        panelExercice.add(enonceLabel);
        panelExercice.add(enonceField);

        JLabel optionsLabel = new JLabel("Réponses possibles (cochez la réponse correcte)");
        panelExercice.add(optionsLabel);

        JPanel optionsPanel = new JPanel();
        optionsPanel.setLayout(new BoxLayout(optionsPanel, BoxLayout.Y_AXIS));

        ButtonGroup buttonGroup = new ButtonGroup();
        ajouterOption(optionsPanel, buttonGroup);
        ajouterOption(optionsPanel, buttonGroup);

        panelExercice.add(optionsPanel);

        // Boutons pour ajuster le nombre de réponses
        JPanel panelAjustement = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton augmenterReponseButton = new JButton("+");
        JButton diminuerReponseButton = new JButton("-");

        augmenterReponseButton.addActionListener(e -> {
            if (optionsPanel.getComponentCount() < 8) {
                ajouterOption(optionsPanel, buttonGroup);
                panelExercice.revalidate();
                panelExercice.repaint();
            }
        });

        diminuerReponseButton.addActionListener(e -> {
            if (optionsPanel.getComponentCount() > 2) {
                optionsPanel.remove(optionsPanel.getComponentCount() - 1);
                panelExercice.revalidate();
                panelExercice.repaint();
            }
        });

        panelAjustement.add(augmenterReponseButton);
        panelAjustement.add(diminuerReponseButton);
        panelExercice.add(panelAjustement);

        panelCentre.add(panelExercice);

        // Ajouter le nom de l'exercice à la liste
        exerciceListModel.addElement("Exercice " + (exerciceListModel.getSize() + 1));

        panelCentre.revalidate();
        panelCentre.repaint();
    }

    // Méthode pour ajouter une option de réponse
    private void ajouterOption(JPanel optionsPanel, ButtonGroup buttonGroup) {
        JPanel optionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField optionField = new JTextField(40);
        JRadioButton radioButton = new JRadioButton();
        buttonGroup.add(radioButton);

        optionPanel.add(optionField);
        optionPanel.add(radioButton);
        optionsPanel.add(optionPanel);
    }

    // Méthode pour renommer les exercices dans la liste après suppression
    private void renommerExercices() {
        for (int i = 0; i < exerciceListModel.getSize(); i++) {
            exerciceListModel.set(i, "Exercice " + (i + 1));
        }
    }

    // Méthode pour obtenir l'examen
    public ExamenQCM getExamenQCM() {
        return examenQCM;
    }
}