package projetlong.Student;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import projetlong.GestionneurData;

public class StudentAccountDetails extends JFrame implements ActionListener {
    JPanel contentPane;
    JTextField firstname, lastname, email, username, passwordField, gender;
    JButton okButton;
    int iden;

    public StudentAccountDetails(int iden) {
        super("Détails de l'étudiant");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1014, 550);
        setLocation(230, 110);

        setResizable(false);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblStudentDetails = new JLabel("Détails de l'étudiant");
        lblStudentDetails.setFont(new Font("Times New Roman", Font.PLAIN, 42));
        lblStudentDetails.setBounds(362, 52, 325, 50);
        lblStudentDetails.setForeground(new Color(70, 130, 180));
        contentPane.add(lblStudentDetails);

        JLabel lblFirstName = new JLabel("Prénom");
        lblFirstName.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblFirstName.setBounds(58, 152, 99, 43);
        contentPane.add(lblFirstName);

        JLabel lblLastName = new JLabel("Nom");
        lblLastName.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblLastName.setBounds(58, 243, 110, 29);
        contentPane.add(lblLastName);

        JLabel lblEmailAddress = new JLabel("Adresse email");
        lblEmailAddress.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblEmailAddress.setBounds(58, 324, 124, 36);
        contentPane.add(lblEmailAddress);

        // Obtenir les données de l'étudiant à partir du fichier de propriétés
        GestionneurData gestionneur = new GestionneurData("donneesUtilisateurs.properties");
        int currentStudentID = iden; // Utiliser l'identifiant passé en argument
        String firstName = gestionneur.obtenirPropriete(currentStudentID, "student", "fname");
        String lastName = gestionneur.obtenirPropriete(currentStudentID, "student", "lname");
        String emailId = gestionneur.obtenirPropriete(currentStudentID, "student", "email");
        String userName = gestionneur.obtenirPropriete(currentStudentID, "student", "username");
        String password = gestionneur.obtenirPropriete(currentStudentID, "student", "password");
        String userGender = gestionneur.obtenirPropriete(currentStudentID, "student", "gender");

        if (firstName == null || lastName == null || emailId == null || userName == null || password == null || userGender == null) {
            JOptionPane.showMessageDialog(null, "Non trouvé");
        }

        firstname = createStyledTextField(firstName);
        firstname.setBounds(214, 151, 228, 50);
        contentPane.add(firstname);

        lastname = createStyledTextField(lastName);
        lastname.setBounds(214, 235, 228, 50);
        contentPane.add(lastname);

        email = createStyledTextField(emailId);
        email.setBounds(214, 320, 320, 50);
        contentPane.add(email);

        username = createStyledTextField(userName);
        username.setBounds(707, 151, 228, 50);
        contentPane.add(username);

        JLabel lblUsername = new JLabel("Nom d'utilisateur");
        lblUsername.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblUsername.setBounds(542, 159, 160, 29);
        contentPane.add(lblUsername);

        JLabel lblPassword = new JLabel("Mot de passe");
        lblPassword.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblPassword.setBounds(542, 245, 130, 24);
        contentPane.add(lblPassword);

        passwordField = createStyledTextField(password);
        passwordField.setBounds(707, 235, 228, 50);
        contentPane.add(passwordField);

        JLabel lblGender = new JLabel("Genre");
        lblGender.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblGender.setBounds(542, 321, 99, 24);
        contentPane.add(lblGender);

        gender = createStyledTextField(userGender);
        gender.setBounds(707, 311, 228, 50);
        contentPane.add(gender);

        okButton = new JButton("Ok");
        styleButton(okButton);
        okButton.setBounds(410, 440, 228, 60);
        okButton.addActionListener(this);
        contentPane.add(okButton);

        setVisible(true);
    }

    private JTextField createStyledTextField(String text) {
        JTextField textField = new JTextField(text);
        textField.setFont(new Font("Tahoma", Font.PLAIN, 32));
        textField.setEditable(false);
        textField.setBorder(new CompoundBorder(new LineBorder(new Color(192, 192, 192), 1), new EmptyBorder(10, 10, 10, 10)));
        return textField;
    }

    private void styleButton(JButton button) {
        button.setFont(new Font(Font.SERIF, Font.BOLD, 18));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(Color.WHITE, 2),
                new EmptyBorder(5, 15, 5, 15)
        ));
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == okButton) {
            dispose();
        }
    }

    public static void main(String[] args) {
        // Exemple d'utilisation
        new StudentAccountDetails(1); // Utilisez un identifiant d'étudiant pour tester
    }
}
