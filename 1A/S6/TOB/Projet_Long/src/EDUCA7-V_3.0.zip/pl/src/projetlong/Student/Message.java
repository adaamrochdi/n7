package projetlong.Student;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import projetlong.GestionneurData;

public class Message extends JFrame implements ActionListener {
    JLabel title, toLbl, fromLbl, messageLbl;
    JTextField toTxt, fromTxt;
    JTextArea messageTxt;
    JButton sendBtn;
    JPanel mainPanel;
    GestionneurData gestionnaire;
    int fromId, toId;

    public Message(int fromId, String toName, int toId) {
        super("Nouveau Message");
        this.fromId = fromId;
        this.toId = toId;
        setLayout(new BorderLayout());

        gestionnaire = new GestionneurData("messages.properties");

        title = new JLabel("Nouveau Message", JLabel.CENTER);
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        title.setBackground(new Color(70, 130, 180));
        title.setForeground(Color.WHITE);
        title.setOpaque(true);
        title.setBorder(new EmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(Color.WHITE);
        add(mainPanel, BorderLayout.CENTER);

        toLbl = new JLabel("À :");
        toLbl.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        toLbl.setBounds(30, 30, 100, 30);
        mainPanel.add(toLbl);

        toTxt = new JTextField(toName);
        toTxt.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        toTxt.setBounds(140, 30, 300, 30);
        toTxt.setEditable(false);
        mainPanel.add(toTxt);

        messageLbl = new JLabel("Message :");
        messageLbl.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        messageLbl.setBounds(30, 80, 100, 30);
        mainPanel.add(messageLbl);

        messageTxt = new JTextArea();
        messageTxt.setLineWrap(true);
        messageTxt.setWrapStyleWord(true);
        messageTxt.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        messageTxt.setBorder(new CompoundBorder(
                new LineBorder(new Color(192, 192, 192), 1),
                new EmptyBorder(10, 10, 10, 10)
        ));
        JScrollPane scrollPane = new JScrollPane(messageTxt);
        scrollPane.setBounds(30, 120, 500, 200);
        mainPanel.add(scrollPane);

        sendBtn = new JButton("Envoyer");
        styleButton(sendBtn);
        sendBtn.setBounds(430, 330, 100, 40);
        mainPanel.add(sendBtn);

        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 500);
        setLocation(420, 260);
        setVisible(true);
    }

    private void styleButton(JButton button) {
        button.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(Color.WHITE),
                new EmptyBorder(5, 15, 5, 15)
        ));
        button.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == sendBtn) {
            String messageContent = messageTxt.getText();
            if (!messageContent.isEmpty()) {
                int newMessageId = gestionnaire.identifiantValableMsg();
                gestionnaire.definirPropriete(newMessageId, "message", "to_ID", String.valueOf(toId));
                gestionnaire.definirPropriete(newMessageId, "message", "from_ID", String.valueOf(fromId));
                gestionnaire.definirPropriete(newMessageId, "message", "content", messageContent);
                gestionnaire.definirPropriete(newMessageId, "message", "timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Timestamp(new Date().getTime())));
                gestionnaire.definirPropriete(newMessageId, "message", "read", "no");

                JOptionPane.showMessageDialog(this, "Message envoyé !");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Le message ne peut pas être vide.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        // Exemple d'utilisation
    }
}
