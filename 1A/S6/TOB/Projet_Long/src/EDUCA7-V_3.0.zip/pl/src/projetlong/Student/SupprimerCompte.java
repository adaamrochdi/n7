package projetlong.Student;

import projetlong.GestionneurData;
import projetlong.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SupprimerCompte extends JFrame implements ActionListener {
    Integer IndiceValidePourMoment;
    private JButton boutonConfirmer, boutonAnnuler;
    int ident;

    public SupprimerCompte(int identifiant) {
        setTitle("Supprimer Compte");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel label = new JLabel("Êtes-vous sûr de vouloir supprimer votre compte ?", JLabel.CENTER);
        label.setFont(new Font("Tahoma", Font.PLAIN, 16));
        add(label, BorderLayout.CENTER);

        JPanel panelBoutons = new JPanel();
        boutonConfirmer = new JButton("Confirmer");
        boutonAnnuler = new JButton("Annuler");

        boutonConfirmer.addActionListener(this);
        boutonAnnuler.addActionListener(this);

        panelBoutons.add(boutonConfirmer);
        panelBoutons.add(boutonAnnuler);

        add(panelBoutons, BorderLayout.SOUTH);

        setVisible(true);
        this.ident = identifiant;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        


        if (e.getSource() == boutonConfirmer) {
            GestionneurData gestionnaire = new GestionneurData("donneesUtilisateurs.properties");
            IndiceValidePourMoment = gestionnaire.identifiantValable() - 1; // Utiliser le dernier identifiant valide
            gestionnaire.supprimerCompte( IndiceValidePourMoment, "student");
            JOptionPane.showMessageDialog(this, "Compte supprimé avec succès.");
            dispose();
            
        } else if (e.getSource() == boutonAnnuler) {
            dispose();
        }
    }

    public static void main(String[] args) {
    }
}
