package projetlong.Student;

import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import projetlong.GestionneurData;

public class GererProfil extends JFrame implements ActionListener, FocusListener {
    JPanel panneau;
    JTextField nouveauPrenom, nouveauNom, nouveauEmail, nouveauNomUtilisateur;
    JPasswordField champMotDePasse;
    JButton boutonSauvegarder, boutonTelechargerPhoto;
    JLabel validationNouveauPrenom, validationNouveauNom, validationNouveauEmail, validationNouveauNomUtilisateur, validationMotDePasse, labelPhotoProfil;
    FileInputStream fis = null;
    File fichier = null;
    Integer IndiceValidePourMoment;

    public GererProfil() {
        super("Gérer Profil Étudiant");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1014, 515);
        setLocation(230, 110);
        setResizable(false);
        panneau = new JPanel();
        panneau.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(panneau);
        panneau.setLayout(null);

        labelPhotoProfil = new JLabel();
        labelPhotoProfil.setIcon(new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/uploadPicIcon.png")));
        labelPhotoProfil.setBounds(456, 18, 96, 96);
        panneau.add(labelPhotoProfil);

        boutonTelechargerPhoto = new JButton("Télécharger");
        boutonTelechargerPhoto.setBounds(470, 120, 100, 30);
        boutonTelechargerPhoto.addActionListener(this);
        panneau.add(boutonTelechargerPhoto);

        JLabel labelNouveauPrenom = new JLabel("Nouveau Prénom");
        labelNouveauPrenom.setFont(new Font("Tahoma", Font.PLAIN, 20));
        labelNouveauPrenom.setBounds(58, 152, 200, 43);
        panneau.add(labelNouveauPrenom);

        JLabel labelNouveauNom = new JLabel("Nouveau Nom");
        labelNouveauNom.setFont(new Font("Tahoma", Font.PLAIN, 20));
        labelNouveauNom.setBounds(58, 243, 200, 29);
        panneau.add(labelNouveauNom);

        JLabel labelNouveauEmail = new JLabel("Nouvelle Adresse Email");
        labelNouveauEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
        labelNouveauEmail.setBounds(58, 324, 250, 36);
        panneau.add(labelNouveauEmail);

        validationNouveauPrenom = new JLabel();
        nouveauPrenom = new JTextField();
        nouveauPrenom.setFont(new Font("Tahoma", Font.PLAIN, 32));
        nouveauPrenom.setBounds(270, 151, 228, 50);
        nouveauPrenom.addFocusListener(this);
        validationNouveauPrenom.setBounds(270, 205, 150, 10);
        panneau.add(validationNouveauPrenom);
        panneau.add(nouveauPrenom);
        nouveauPrenom.setColumns(10);

        validationNouveauNom = new JLabel();
        nouveauNom = new JTextField();
        nouveauNom.setFont(new Font("Tahoma", Font.PLAIN, 32));
        nouveauNom.setBounds(270, 235, 228, 50);
        nouveauNom.addFocusListener(this);
        validationNouveauNom.setBounds(270, 289, 150, 10);
        panneau.add(validationNouveauNom);
        panneau.add(nouveauNom);
        nouveauNom.setColumns(10);

        validationNouveauEmail = new JLabel();
        nouveauEmail = new JTextField();
        nouveauEmail.setFont(new Font("Tahoma", Font.PLAIN, 32));
        nouveauEmail.setBounds(270, 320, 228, 50);
        nouveauEmail.addFocusListener(this);
        validationNouveauEmail.setBounds(270, 374, 150, 10);
        panneau.add(validationNouveauEmail);
        panneau.add(nouveauEmail);
        nouveauEmail.setColumns(10);

        validationNouveauNomUtilisateur = new JLabel();
        nouveauNomUtilisateur = new JTextField();
        nouveauNomUtilisateur.setFont(new Font("Tahoma", Font.PLAIN, 32));
        nouveauNomUtilisateur.setBounds(707, 151, 228, 50);
        nouveauNomUtilisateur.addFocusListener(this);
        validationNouveauNomUtilisateur.setBounds(707, 205, 150, 10);
        panneau.add(validationNouveauNomUtilisateur);
        panneau.add(nouveauNomUtilisateur);
        nouveauNomUtilisateur.setColumns(10);

        JLabel labelNouveauNomUtilisateur = new JLabel("Nouveau Nom d'utilisateur");
        labelNouveauNomUtilisateur.setFont(new Font("Tahoma", Font.PLAIN, 20));
        labelNouveauNomUtilisateur.setBounds(540, 159, 220, 29);
        panneau.add(labelNouveauNomUtilisateur);

        JLabel labelMotDePasse = new JLabel("Mot de passe");
        labelMotDePasse.setFont(new Font("Tahoma", Font.PLAIN, 20));
        labelMotDePasse.setBounds(540, 245, 120, 24);
        panneau.add(labelMotDePasse);

        champMotDePasse = new JPasswordField();
        champMotDePasse.setFont(new Font("Tahoma", Font.PLAIN, 32));
        champMotDePasse.setBounds(707, 235, 228, 50);
        panneau.add(champMotDePasse);

        boutonSauvegarder = new JButton("Sauvegarder");
        boutonSauvegarder.setBounds(410, 400, 228, 60);
        boutonSauvegarder.addActionListener(this);
        panneau.add(boutonSauvegarder);

        chargerInfosProfil();

        setVisible(true);
    }

    private void chargerInfosProfil() {
        GestionneurData gestionnaire = new GestionneurData("donneesUtilisateurs.properties");
        IndiceValidePourMoment = gestionnaire.identifiantValable() - 1; // Utiliser le dernier identifiant valide
        try {
            String prenomTexte = gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "fname");
            String nomTexte = gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "lname");
            String emailTexte = gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "email");
            String nomUtilisateurTexte = gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "username");
            String motDePasseTexte = gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "password");
            String cheminImage = gestionnaire.obtenirPropriete(IndiceValidePourMoment, "student", "picturePath");

            nouveauPrenom.setText(prenomTexte);
            nouveauNom.setText(nomTexte);
            nouveauEmail.setText(emailTexte);
            nouveauNomUtilisateur.setText(nomUtilisateurTexte);
            champMotDePasse.setText(motDePasseTexte);

            if (cheminImage != null) {
                File file = new File(cheminImage);
                fis = new FileInputStream(file);
                labelPhotoProfil.setIcon(redimensionnerImage(cheminImage));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == boutonTelechargerPhoto) {
            JFileChooser choixFichier = new JFileChooser();
            int returnValue = choixFichier.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                fichier = choixFichier.getSelectedFile();
                try {
                    labelPhotoProfil.setIcon(redimensionnerImage(fichier.getAbsolutePath()));
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        } else if (ae.getSource() == boutonSauvegarder) {
            try {
                GestionneurData gestionnaire = new GestionneurData("donneesUtilisateurs.properties");
    
                // Remplacer les propriétés existantes
                gestionnaire.remplacerPropriete(IndiceValidePourMoment, "student", "fname", nouveauPrenom.getText());
                gestionnaire.remplacerPropriete(IndiceValidePourMoment, "student", "lname", nouveauNom.getText());
                gestionnaire.remplacerPropriete(IndiceValidePourMoment, "student", "email", nouveauEmail.getText());
                gestionnaire.remplacerPropriete(IndiceValidePourMoment, "student", "username", nouveauNomUtilisateur.getText());
                gestionnaire.remplacerPropriete(IndiceValidePourMoment, "student", "password", new String(champMotDePasse.getPassword()));
                if (fichier != null) {
                    gestionnaire.remplacerPropriete(IndiceValidePourMoment, "student", "picturePath", fichier.getAbsolutePath());
                }
    
                JOptionPane.showMessageDialog(null, "Profil mis à jour avec succès !");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    


    public ImageIcon redimensionnerImage(String cheminImage) {
        BufferedImage imageTampon = null;
        try {
            imageTampon = ImageIO.read(new File(cheminImage));
        } catch (IOException ex) {
            Logger.getLogger(GererProfil.class.getName()).log(Level.SEVERE, null, ex);
        }
        int largeur = imageTampon.getWidth();
        BufferedImage imageCirculaire = new BufferedImage(largeur, largeur, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = imageCirculaire.createGraphics();
        g2.setClip(new Ellipse2D.Float(0, 0, largeur, largeur));
        g2.drawImage(imageTampon, 0, 0, largeur, largeur, null);
        ImageIcon icone = new ImageIcon(imageCirculaire);
        Image imageRedimensionnee = icone.getImage().getScaledInstance(96, 96, Image.SCALE_DEFAULT);
        ImageIcon iconeRedimensionnee = new ImageIcon(imageRedimensionnee);
        return iconeRedimensionnee;
    }

    @Override
    public void focusGained(FocusEvent e) {
        // Gestion du focus ici
    }

    @Override
    public void focusLost(FocusEvent e) {
        // Gestion de la perte de focus ici
    }

    public static void main(String[] args) {
        new GererProfil(); // L'identifiant de l'étudiant doit être passé en paramètre
    }
}
