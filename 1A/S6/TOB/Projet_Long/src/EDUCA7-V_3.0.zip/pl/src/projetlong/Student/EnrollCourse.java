package projetlong.Student;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import projetlong.GestionneurData;

public class EnrollCourse extends JFrame implements ActionListener, ListSelectionListener {
    JLabel title, themeCbLbl, courseDescriptionLbl;
    JTable coursesTable;
    DefaultTableModel tableModel;
    JButton enrollBtn;
    JPanel middlePanel;
    JScrollPane scroll;
    GestionneurData coursGestionnaire;
    GestionneurData etudiantGestionnaire;
    int studentId;
    JComboBox<String> themesCb;

    public EnrollCourse(int studentId) {
        super("Inscription à un cours");
        this.studentId = studentId;
        coursGestionnaire = new GestionneurData("Cours.properties");
        etudiantGestionnaire = new GestionneurData("donneesUtilisateurs.properties");
        setLayout(new BorderLayout());

        title = new JLabel("Inscription à un cours", JLabel.CENTER);
        title.setFont(new Font(Font.SERIF, Font.BOLD, 26));
        title.setBackground(new Color(70, 130, 180));
        title.setForeground(Color.WHITE);
        title.setOpaque(true);
        title.setBorder(new EmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        middlePanel = new JPanel();
        middlePanel.setLayout(null);
        middlePanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        add(middlePanel, BorderLayout.CENTER);

        themeCbLbl = new JLabel("Sélectionner un thème");
        themeCbLbl.setFont(new Font(Font.SERIF, Font.BOLD, 16));
        themeCbLbl.setBounds(80, 30, 200, 28);
        themeCbLbl.setHorizontalAlignment(JLabel.CENTER);
        themeCbLbl.setBorder(new EmptyBorder(0, 0, 10, 0));
        middlePanel.add(themeCbLbl);

        themesCb = new JComboBox<>(coursGestionnaire.obtenirCoursThemes());
        themesCb.setSelectedIndex(-1);
        themesCb.setBounds(300, 30, 250, 28);
        themesCb.setFont(new Font(Font.SERIF, Font.PLAIN, 16));
        themesCb.addActionListener(this);
        middlePanel.add(themesCb);

        courseDescriptionLbl = new JLabel("Description des cours");
        courseDescriptionLbl.setFont(new Font(Font.SERIF, Font.BOLD, 16));
        courseDescriptionLbl.setBounds(80, 80, 200, 28);
        courseDescriptionLbl.setHorizontalAlignment(JLabel.CENTER);
        courseDescriptionLbl.setBorder(new EmptyBorder(10, 0, 10, 0));
        middlePanel.add(courseDescriptionLbl);

        tableModel = new DefaultTableModel(new Object[]{"Fichiers de cours"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        coursesTable = new JTable(tableModel);
        coursesTable.setFont(new Font(Font.SERIF, Font.PLAIN, 14));
        coursesTable.getSelectionModel().addListSelectionListener(this);
        scroll = new JScrollPane(coursesTable);
        scroll.setBounds(300, 120, 250, 150);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.setBorder(new CompoundBorder(
            new LineBorder(new Color(192, 192, 192), 1),
            new EmptyBorder(10, 10, 10, 10)
        ));
        middlePanel.add(scroll);

        enrollBtn = new JButton("S'inscrire");
        enrollBtn.setFont(new Font(Font.SERIF, Font.BOLD, 15));
        enrollBtn.setHorizontalAlignment(JButton.CENTER);
        enrollBtn.setBackground(new Color(70, 130, 180));
        enrollBtn.setForeground(Color.WHITE);
        enrollBtn.setFocusPainted(false);
        enrollBtn.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(Color.WHITE, 2),
            new EmptyBorder(5, 15, 5, 15)
        ));
        enrollBtn.addActionListener(this);
        add(enrollBtn, BorderLayout.SOUTH);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(700, 400);
        setLocation(420, 320);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == themesCb) {
            Object selected = themesCb.getSelectedItem();
            if (selected != null) {
                String themeName = selected.toString();
                List<String> courses = getCoursesByTheme(themeName);
                tableModel.setRowCount(0); 
                for (String course : courses) {
                    String fileName = new File(course).getName();
                    fileName = fileName.substring(0, fileName.lastIndexOf(".")); // Remove extension
                    tableModel.addRow(new Object[]{fileName});
                }
            }
        } else if (ae.getSource() == enrollBtn) {
            int selectedRow = coursesTable.getSelectedRow();
            if (selectedRow != -1) {
                String fileName = (String) tableModel.getValueAt(selectedRow, 0);
                int courseId = getCourseIdByPath(fileName);
                String currentCourses = etudiantGestionnaire.obtenirCoursSuivis(studentId);
                if (currentCourses == null || currentCourses.isEmpty()) {
                    currentCourses = String.valueOf(courseId);
                } else {
                    currentCourses += "," + courseId;
                }
                etudiantGestionnaire.enregistrerCoursSuivis(studentId, currentCourses);
                JOptionPane.showMessageDialog(null, "Inscription au cours réussie !");
                
            } else {
                JOptionPane.showMessageDialog(this, "Veuillez sélectionner un cours dans la liste.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        // Do nothing for now
    }

    private List<String> getCoursesByTheme(String theme) {
        List<String> courses = new ArrayList<>();
        String currentCourses = etudiantGestionnaire.obtenirCoursSuivis(studentId);
        List<String> enrolledCourses = new ArrayList<>();
        if (currentCourses != null && !currentCourses.isEmpty()) {
            for (String courseId : currentCourses.split(",")) {
                enrolledCourses.add(coursGestionnaire.obtenirCoursPath(Integer.parseInt(courseId)));
            }
        }
        for (int i = 1; i <= coursGestionnaire.identifiantValableCours(); i++) {
            if (theme.equals(coursGestionnaire.obtenirPropriete(i, "cours", "theme"))) {
                String coursePath = coursGestionnaire.obtenirCoursPath(i);
                if (!enrolledCourses.contains(coursePath)) {
                    courses.add(coursePath);
                }
            }
        }
        return courses;
    }

    private int getCourseIdByPath(String path) {
        for (int i = 1; i <= coursGestionnaire.identifiantValableCours(); i++) {
            String coursePath = coursGestionnaire.obtenirCoursPath(i);
            if (coursePath != null && new File(coursePath).getName().equals(path)) {
                return i;
            }
        }
        return -1; // Id non trouvé
    }

    public static void main(String[] args) {
        // Utilisation de l'exemple avec un identifiant d'étudiant
        new EnrollCourse(1);
    }
}
