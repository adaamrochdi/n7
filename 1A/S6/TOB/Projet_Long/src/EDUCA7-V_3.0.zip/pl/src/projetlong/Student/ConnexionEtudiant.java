package projetlong.Student;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import projetlong.GestionneurData;

public class ConnexionEtudiant extends JFrame implements ActionListener {
    JLabel labelNomUtilisateur, labelMotDePasse;
    JTextField champNomUtilisateur;
    JPasswordField champMotDePasse;
    JButton boutonConnexion, boutonAnnuler;
    public int identifiant;

    public ConnexionEtudiant() {
        super("Connexion Étudiant");

        setLayout(null);

        labelNomUtilisateur = new JLabel("Nom d'utilisateur");
        labelNomUtilisateur.setBounds(40, 20, 150, 30);
        labelNomUtilisateur.setFont(new Font("Arial", Font.BOLD, 14));
        labelNomUtilisateur.setForeground(new Color(70, 130, 180));
        add(labelNomUtilisateur);

        labelMotDePasse = new JLabel("Mot de passe");
        labelMotDePasse.setBounds(40, 70, 150, 30);
        labelMotDePasse.setFont(new Font("Arial", Font.BOLD, 14));
        labelMotDePasse.setForeground(new Color(70, 130, 180));
        add(labelMotDePasse);

        champNomUtilisateur = new JTextField();
        champNomUtilisateur.setBounds(200, 20, 150, 30);
        champNomUtilisateur.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(70, 130, 180), 1),
            new EmptyBorder(5, 5, 5, 5)
        ));
        add(champNomUtilisateur);

        champMotDePasse = new JPasswordField();
        champMotDePasse.setBounds(200, 70, 150, 30);
        champMotDePasse.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(70, 130, 180), 1),
            new EmptyBorder(5, 5, 5, 5)
        ));
        add(champMotDePasse);

        ImageIcon icone = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/second.jpg"));
        Image image = icone.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
        ImageIcon iconeRedimensionnee = new ImageIcon(image);
        JLabel labelImage = new JLabel(iconeRedimensionnee);
        labelImage.setBounds(400, 20, 150, 150);
        add(labelImage);

        boutonConnexion = new JButton("Connexion");
        boutonConnexion.setBounds(40, 140, 150, 40);
        styleButton(boutonConnexion);
        add(boutonConnexion);

        boutonAnnuler = new JButton("Annuler");
        boutonAnnuler.setBounds(200, 140, 150, 40);
        styleButton(boutonAnnuler);
        add(boutonAnnuler);

        getContentPane().setBackground(Color.WHITE);

        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 250);
        setLocation(420, 365);
    }

    private void styleButton(JButton button) {
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(Color.WHITE, 2),
            new EmptyBorder(5, 15, 5, 15)
        ));
        button.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == boutonConnexion) {
            String utilisateur = champNomUtilisateur.getText();
            String motDePasse = String.valueOf(champMotDePasse.getPassword());

            // Vérification des identifiants avec le gestionnaire de données
            if (verifier(utilisateur, motDePasse)) {
                JOptionPane.showMessageDialog(null, "Connexion réussie");
                setVisible(false);
                GestionneurData gestionnaire = new GestionneurData("donneesUtilisateurs.properties");
                new Student(gestionnaire.identifiantActuel(utilisateur, motDePasse));
                this.identifiant = gestionnaire.identifiantActuel(utilisateur, motDePasse);
            } else {
                JOptionPane.showMessageDialog(null, "Identifiants invalides");
            }
        } else if (ae.getSource() == boutonAnnuler) {
            dispose();
        }
    }

    // Méthode pour vérifier les identifiants avec le gestionnaire de données
    private boolean verifier(String utilisateur, String motDePasse) {
        GestionneurData gestionnaire = new GestionneurData("donneesUtilisateurs.properties");
        // Vérifier si l'utilisateur et le mot de passe correspondent
        return gestionnaire.verifierIdentifiants(utilisateur, motDePasse);
    }

    public static void main(String[] args) {
        new ConnexionEtudiant();
    }
}
