package projetlong;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.io.*;

public class GestionneurData {
    private Properties props;
    private String fichierProperties;

    public GestionneurData(String Prop) {
        this.fichierProperties = Prop;
        props = new Properties();
        chargerDonnees();
    }

    private void chargerDonnees() {
        try (InputStream input = new FileInputStream(fichierProperties)) {
            props.load(input);
        } catch (IOException ex) {
            System.out.println("Erreur lors du chargement des données: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void enregistrerDonnees() {
        try (OutputStream output = new FileOutputStream(fichierProperties)) {
            props.store(output, "Données des Utilisateurs");
        } catch (IOException ex) {
            System.out.println("Erreur lors de l'enregistrement des données: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void definirPropriete(int id, String type, String cle, String valeur) {
        props.setProperty(type + "." + id + "." + cle, valeur);
        enregistrerDonnees();
    }
    public int identifiantValableMsg() {
        // Chargement des propriétés existantes
        Properties properties = props;

        // Récupération de tous les identifiants existants
        Set<Object> clefs = properties.keySet();
        int idMax = 0;

        // Parcours des identifiants existants pour trouver le plus grand
        for (Object clef : clefs) {
            String clefStr = (String) clef;
            if (clefStr.startsWith("message.")) {
                int id = Integer.parseInt(clefStr.split("\\.")[1]);
                if (id > idMax) {
                    idMax = id;
                }
            }
        }

        // L'identifiant suivant sera l'identifiant maximum + 1
        return idMax + 1;
    }




    public int identifiantValableCours() {
        // Chargement des propriétés existantes
        Properties properties = props;

        // Récupération de tous les identifiants existants
        Set<Object> clefs = properties.keySet();
        int idMax = 0;

        // Parcours des identifiants existants pour trouver le plus grand
        for (Object clef : clefs) {
            String clefStr = (String) clef;
            if (clefStr.startsWith("cours.")) {
                int id = Integer.parseInt(clefStr.split("\\.")[1]);
                if (id > idMax) {
                    idMax = id;
                }
            }
        }

        // L'identifiant suivant sera l'identifiant maximum + 1
        return idMax + 1;
    }


    public int identifiantValable() {
        // Chargement des propriétés existantes
        Properties properties = props;

        // Récupération de tous les identifiants existants
        Set<Object> clefs = properties.keySet();
        int idMax = 0;

        // Parcours des identifiants existants pour trouver le plus grand
        for (Object clef : clefs) {
            String clefStr = (String) clef;
            if (clefStr.startsWith("student.")) {
                int id = Integer.parseInt(clefStr.split("\\.")[1]);
                if (id > idMax) {
                    idMax = id;
                }
            }
        }

        // L'identifiant suivant sera l'identifiant maximum + 1
        return idMax + 1;
    }

    
    public String obtenirPropriete(int id, String type, String cle) {
        return props.getProperty(type + "." + id + "." + cle);
    }

    public boolean verifierIdentifiants(String utilisateur, String motDePasse) {
        // Accéder au gestionnaire de données pour obtenir les informations des utilisateurs
    
        // Récupérer le nombre total d'utilisateurs
        int nombreUtilisateurs = this.identifiantValable();
         int j = 0;
         
        // Parcourir tous les utilisateurs
        for (int i = 1; i < nombreUtilisateurs; i++) {
            // Récupérer les informations de l'utilisateur courant
            String username = this.obtenirPropriete(i, "student", "username");
            String password = this.obtenirPropriete(i, "student", "password");
            
            if ((username.equals(utilisateur)) && (password.equals(motDePasse)) ){
                j = j+1;

            }
                
            }
        return (!(j==0));
    
    }

    public void remplacerPropriete(int id, String type, String cle, String valeur) {
        String key = type + "." + id + "." + cle;
        props.remove(key);
        props.setProperty(key, valeur);
        enregistrerDonnees();
    }
    
    public void supprimerCompte(int id, String type) {
        String prefix = type + "." + id + ".";
        props.keySet().removeIf(key -> ((String) key).startsWith(prefix));
        enregistrerDonnees();
    }
    public String[] obtenirCoursThemes() {
        Set<String> uniqueThemes = new HashSet<>();
        for (Object clef : props.keySet()) {
            String clefStr = clef.toString();
            if (clefStr.startsWith("cours.") && clefStr.endsWith(".theme")) {
                uniqueThemes.add(props.getProperty(clefStr));
            }
        }
        return uniqueThemes.toArray(new String[0]);
    }
    
    public String obtenirCoursPath(int id) {
        return props.getProperty("cours." + id + ".path");
    }

    public void enregistrerCoursSuivis(int studentId, String courseIds) {
        definirPropriete(studentId, "student", "cours_enr", courseIds);
    }

    public String obtenirCoursSuivis(int studentId) {
        return obtenirPropriete(studentId, "student", "cours_enr");
    }
    public int identifiantActuel(String utilisateur, String motDePasse) {
        // Accéder au gestionnaire de données pour obtenir les informations des utilisateurs
    
        // Récupérer le nombre total d'utilisateurs
        int nombreUtilisateurs = this.identifiantValable();
         int j = 0;
         
        // Parcourir tous les utilisateurs
        for (int i = 1; i < nombreUtilisateurs; i++) {
            // Récupérer les informations de l'utilisateur courant
            String username = this.obtenirPropriete(i, "student", "username");
            String password = this.obtenirPropriete(i, "student", "password");
            
            if ((username.equals(utilisateur)) && (password.equals(motDePasse)) ){
                j = i;

            }
                
            }
        return j;
    
    }






    public int getNombreUtilisateurs() {
        int nombreUtilisateurs = 0;

        for (String key : props.stringPropertyNames()) {
            if (key.startsWith("student.")) {
                nombreUtilisateurs++;
            }
        }

        return nombreUtilisateurs;
    }




    public static void main(String[] args) {
        GestionneurData gestionnaire = new GestionneurData("donneesUtilisateurs.properties");
        
    
        // Affichage des données de John Doe
  
        
    }
}
