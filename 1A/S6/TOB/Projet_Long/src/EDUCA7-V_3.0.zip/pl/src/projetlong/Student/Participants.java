package projetlong.Student;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.border.LineBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.BorderFactory;
import projetlong.GestionneurData;

public class Participants extends JFrame implements ActionListener {
    JLabel title, courseCbLbl;
    JPanel middlePanel;
    JScrollPane scroll;
    JTable table;
    DefaultTableModel model;
    JButton showContactsBtn;
    GestionneurData gestionnaire;
    int iden;

    public Participants(int iban) {
        super("Voir les Participants");
        setLayout(new BorderLayout());

        gestionnaire = new GestionneurData("donneesUtilisateurs.properties");

        title = new JLabel("Participants", JLabel.CENTER);
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        title.setBackground(new Color(70, 130, 180));
        title.setForeground(Color.WHITE);
        title.setOpaque(true);
        title.setBorder(new EmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        middlePanel = new JPanel();
        middlePanel.setLayout(null);
        middlePanel.setBackground(Color.WHITE);
        add(middlePanel, BorderLayout.CENTER);

        model = new DefaultTableModel(new Object[]{"ID", "Nom", "Email", "Dernière Connexion", "Rôle", "Score"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        JTableHeader header = table.getTableHeader();
        header.setBackground(new Color(173, 216, 230));
        header.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        table.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        table.setRowHeight(30);
        table.setSelectionBackground(new Color(173, 216, 230));
        table.setSelectionForeground(Color.BLACK);
        table.setGridColor(new Color(192, 192, 192));
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(20, 95, 550, 245);
        pane.setBorder(BorderFactory.createLineBorder(new Color(192, 192, 192), 1));
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        middlePanel.add(pane);

        showContactsBtn = new JButton("Utilisateurs");
        styleButton(showContactsBtn);
        showContactsBtn.setToolTipText("Cliquer pour actualiser la liste des participants.");
        add(showContactsBtn, BorderLayout.SOUTH);

        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 450);
        setLocation(420, 260);
        setVisible(true);
        this.iden = iban;
    }

    private void styleButton(JButton button) {
        button.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(Color.WHITE),
            new EmptyBorder(5, 15, 5, 15)
        ));
        button.addActionListener(this);
        
        // Ajouter des effets dynamiques
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(100, 149, 237));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(70, 130, 180));
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == showContactsBtn) {
            // Effacer tous les enregistrements du JTable
            model.setRowCount(0);

            List<Student> students = new ArrayList<>();
            
           
            for (int i = 1; i < gestionnaire.identifiantValable(); i++) {
               
                String username = gestionnaire.obtenirPropriete(i, "student", "username");
                if (username != null && gestionnaire.obtenirPropriete(i, "student", "score") != null) {
                    String firstName = gestionnaire.obtenirPropriete(i, "student", "fname");
                    String lastName = gestionnaire.obtenirPropriete(i, "student", "lname");
                    String email = gestionnaire.obtenirPropriete(i, "student", "email");
                    String lastLogin = gestionnaire.obtenirPropriete(i, "student", "last_login");
                    String role = "Student";
                    int score = Integer.parseInt(gestionnaire.obtenirPropriete(i, "student", "score"));

                    students.add(new Student(i, firstName + " " + lastName, email, lastLogin, role, score));
                }
            }

            // Trier les étudiants par score
            Collections.sort(students, Comparator.comparingInt(Student::getScore).reversed());

            // Ajouter les étudiants triés au modèle
            for (Student student : students) {
                model.addRow(new Object[]{student.getId(), student.getName(), student.getEmail(), student.getLastLogin(), student.getRole(), student.getScore()});
            }
        }
    }

    private static class Student {
        private int id;
        private String name;
        private String email;
        private String lastLogin;
        private String role;
        private int score;

        public Student(int id, String name, String email, String lastLogin, String role, int score) {
            this.id = id;
            this.name = name;
            this.email = email;
            this.lastLogin = lastLogin;
            this.role = role;
            this.score = score;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getEmail() {
            return email;
        }

        public String getLastLogin() {
            return lastLogin;
        }

        public String getRole() {
            return role;
        }

        public int getScore() {
            return score;
        }
    }

    public static void main(String[] args) {
        // Exemple d'utilisation
        new Participants(1);
    }
}
