package projetlong.Exam;

import java.util.List;

public interface Examen {
	
	/** Ajoute un exercice à l'examen.
	 *  @param L'exercice qu'on veux ajouter.  */
    void ajouterExercice(Exercice exercice);
    /** Supprime un exercice de l'examen.
	 *  @param L'exercice qu'on veux supprimer.  */
    void supprimerExercice(Exercice exercice);
    /** On obtien la listes des exercice dans l'examen.
	 *  @return Listes des exercices.  */
    List<Exercice> obtenirExercices();
}