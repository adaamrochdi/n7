package projetlong;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.Timer;
import javax.swing.border.LineBorder;

public class Main extends JFrame implements ActionListener {
    JPanel panneauEntete, panneauPrincipal;
    JButton boutonConnexion, boutonInscription;
    JLabel titre, horloge;
    JMenuBar barreMenu;
    JMenu menuFichier, menuAPropos;
    JMenuItem itemAProposProjet, itemAProposDeveloppeurs, itemQuitter;

    public Main() {
        super("Educa7");
        setSize(1280, 720);
        setLocation(35, 30);
        setLayout(new BorderLayout());

        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/systemIcon.png"));
        setIconImage(icon.getImage());

        panneauEntete = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon background = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/background.png"));
                Image image = background.getImage();
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        add(panneauEntete, BorderLayout.CENTER);

        // Code de l'entête
        itemAProposProjet = new JMenuItem("À propos du Projet");
        itemAProposDeveloppeurs = new JMenuItem("À propos des Développeurs");
        barreMenu = new JMenuBar();
        menuAPropos = new JMenu("À Propos");
        itemQuitter = new JMenuItem("Quitter");
        // Ajout d'un raccourci clavier pour fermer la fenêtre
        KeyStroke ctrlE = KeyStroke.getKeyStroke(KeyEvent.VK_E, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask());
        itemQuitter.setAccelerator(ctrlE);
        menuFichier = new JMenu("Fichier");
        menuFichier.add(itemQuitter);
        menuAPropos.add(itemAProposProjet);
        menuAPropos.add(itemAProposDeveloppeurs);
        itemQuitter.addActionListener(this);
        itemAProposDeveloppeurs.addActionListener(this);
        itemAProposProjet.addActionListener(this);
        barreMenu.add(menuFichier);
        barreMenu.add(menuAPropos);

        setJMenuBar(barreMenu);

        horloge = new JLabel();
        horloge.setHorizontalAlignment(JLabel.RIGHT);
        DateFormat df = new SimpleDateFormat("yyyy-MMM-dd hh:mm:ss aa");
        Calendar calobj = Calendar.getInstance();
        horloge.setText(df.format(calobj.getTime()));
        horloge.setFont(new Font(Font.SERIF, Font.BOLD, 19));
        horloge.setForeground(new Color(14, 168, 29));
        panneauEntete.add(horloge, BorderLayout.NORTH);

        Timer t = new Timer(500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DateFormat df = new SimpleDateFormat("yyyy-MMM-dd hh:mm:ss aa");
                Calendar calobj = Calendar.getInstance();
                horloge.setText(df.format(calobj.getTime()));
            }
        });
        t.setRepeats(true);
        t.setCoalesce(true);
        t.setInitialDelay(0);
        t.start();

        panneauPrincipal = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon background = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/background2.png"));
                Image image = background.getImage();
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panneauPrincipal.setLayout(null);
        add(panneauPrincipal, BorderLayout.CENTER);

// Code du centre principal
        ImageIcon loginImg1 = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/login.png"));
        Image loginImg2 = loginImg1.getImage().getScaledInstance(96, 96, Image.SCALE_DEFAULT);
        ImageIcon loginImg3 = new ImageIcon(loginImg2);
        boutonConnexion = new JButton("Connexion", loginImg3);
        boutonConnexion.setHorizontalAlignment(JButton.CENTER);
        boutonConnexion.setBounds(350, 220, 190, 150);
        boutonConnexion.setFont(new Font(Font.SERIF, Font.BOLD, 25));
        boutonConnexion.setBackground(new Color(71, 140, 210));
        boutonConnexion.setForeground(Color.WHITE);
        boutonConnexion.setHorizontalTextPosition(JButton.CENTER);
        boutonConnexion.setVerticalTextPosition(JButton.BOTTOM);
        boutonConnexion.setBorder(new LineBorder(Color.WHITE, 2)); // Ajout d'un cadre blanc
        boutonConnexion.addActionListener(this);

        ImageIcon signUpImg1 = new ImageIcon(ClassLoader.getSystemResource("projetlong/icons/signup.png"));
        Image signUpImg2 = signUpImg1.getImage().getScaledInstance(96, 96, Image.SCALE_DEFAULT);
        ImageIcon signUpImg3 = new ImageIcon(signUpImg2);
        boutonInscription = new JButton("Inscription", signUpImg3);
        boutonInscription.setHorizontalAlignment(JButton.CENTER);
        boutonInscription.setBounds(715, 220, 210, 150);
        boutonInscription.setFont(new Font(Font.SERIF, Font.BOLD, 25));
        boutonInscription.setBackground(new Color(71,140,210));
        boutonInscription.setForeground(Color.WHITE);
        boutonInscription.setBorder(new LineBorder(Color.WHITE, 2));
        boutonInscription.setHorizontalTextPosition(JButton.CENTER);
        boutonInscription.setVerticalTextPosition(JButton.BOTTOM);
        boutonInscription.addActionListener(this);

        // Ajout au panneau principal
        panneauPrincipal.add(boutonConnexion);
        panneauPrincipal.add(boutonInscription);

        // Paramètres du cadre
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == boutonConnexion) {
            new Login();
        } else if (ae.getSource() == boutonInscription) {
            new Inscription();
        } else if (ae.getSource() == itemAProposDeveloppeurs) {
            // Afficher les informations sur les développeurs
        } else if (ae.getSource() == itemAProposProjet) {
            // Afficher les informations sur le projet
        } else if (ae.getSource() == itemQuitter) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new Main();
    }
}
